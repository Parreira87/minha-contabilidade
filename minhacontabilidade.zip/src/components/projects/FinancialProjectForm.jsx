import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { X, Save, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function FinancialProjectForm({ isOpen, onClose, onSave, project }) {
  const [formData, setFormData] = useState({
    name: "",
    start_month: new Date().toISOString().slice(0, 7),
    monthly_amount: "",
    storage_type: "banco",
    bank_name: "",
    notes: "",
    is_active: true
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (project) {
      setFormData({
        name: project.name || "",
        start_month: project.start_month || project.month || new Date().toISOString().slice(0, 7),
        monthly_amount: project.monthly_amount?.toString() || "",
        storage_type: project.storage_type || "banco",
        bank_name: project.bank_name || "",
        notes: project.notes || "",
        is_active: project.is_active !== undefined ? project.is_active : true
      });
    } else {
      setFormData({
        name: "",
        start_month: new Date().toISOString().slice(0, 7),
        monthly_amount: "",
        storage_type: "banco",
        bank_name: "",
        notes: "",
        is_active: true
      });
    }
  }, [project, isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const data = {
      ...formData,
      monthly_amount: parseFloat(formData.monthly_amount) || 0
    };

    if (project?.id) {
      await base44.entities.FinancialProject.update(project.id, data);
    } else {
      await base44.entities.FinancialProject.create(data);
    }
    
    setIsLoading(false);
    setShowSuccess(true);
    
    setTimeout(() => {
      setShowSuccess(false);
      onSave();
      onClose();
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-white/95 backdrop-blur-sm rounded-lg"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center"
                >
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </motion.div>
                <p className="text-xl font-bold text-gray-800">Salvo com sucesso!</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-800">
            {project ? "Editar Projeto" : "Novo Projeto Financeiro"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Nome do Projeto *</Label>
            <Input
              placeholder="Ex: Reserva de Emergência"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Mês de Início *</Label>
            <Input
              type="month"
              value={formData.start_month}
              onChange={(e) => setFormData({ ...formData, start_month: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Valor Mensal (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={formData.monthly_amount}
              onChange={(e) => setFormData({ ...formData, monthly_amount: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Onde será guardado? *</Label>
            <Select 
              value={formData.storage_type} 
              onValueChange={(v) => setFormData({ ...formData, storage_type: v, bank_name: v === 'cofre' ? '' : formData.bank_name })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="cofre">Cofre</SelectItem>
                <SelectItem value="banco">Banco</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {formData.storage_type === 'banco' && (
            <div className="space-y-2">
              <Label>Nome do Banco *</Label>
              <Input
                placeholder="Ex: Banco do Brasil, Nubank, etc."
                value={formData.bank_name}
                onChange={(e) => setFormData({ ...formData, bank_name: e.target.value })}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label>Observações</Label>
            <Textarea
              placeholder="Observações adicionais sobre o projeto..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <Label>Projeto ativo?</Label>
            <Switch
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-purple-600 hover:bg-purple-700">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}