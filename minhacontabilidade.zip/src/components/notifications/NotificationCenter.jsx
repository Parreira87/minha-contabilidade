import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Bell, CheckCircle, AlertTriangle, Clock, X } from "lucide-react";
import { format, differenceInDays, isPast, isToday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";

export default function NotificationCenter() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions-notifications'],
    queryFn: () => base44.entities.Transaction.list('-due_date', 1000),
    refetchInterval: 60000, // Atualiza a cada 1 minuto
  });

  const markAsPaidMutation = useMutation({
    mutationFn: ({ id }) => base44.entities.Transaction.update(id, { is_paid: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions-notifications'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filtrar transações pendentes que vencem nos próximos 7 dias ou estão atrasadas
  const upcomingTransactions = transactions
    .filter(t => {
      if (t.is_paid || !t.due_date) return false;
      const dueDate = new Date(t.due_date);
      const daysUntilDue = differenceInDays(dueDate, new Date());
      return daysUntilDue <= 7; // Próximos 7 dias ou atrasadas (negativo)
    })
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date));

  const overdueCount = upcomingTransactions.filter(t => isPast(new Date(t.due_date)) && !isToday(new Date(t.due_date))).length;

  const getPriorityColor = (dueDate) => {
    const days = differenceInDays(new Date(dueDate), new Date());
    if (days < 0) return 'bg-red-100 border-red-300 text-red-700';
    if (days === 0) return 'bg-orange-100 border-orange-300 text-orange-700';
    if (days <= 3) return 'bg-yellow-100 border-yellow-300 text-yellow-700';
    return 'bg-blue-100 border-blue-300 text-blue-700';
  };

  const getPriorityLabel = (dueDate) => {
    const days = differenceInDays(new Date(dueDate), new Date());
    if (days < 0) return `${Math.abs(days)}d atraso`;
    if (days === 0) return 'Vence hoje';
    if (days === 1) return 'Vence amanhã';
    return `${days} dias`;
  };

  const handleMarkAsPaid = (transaction) => {
    markAsPaidMutation.mutate({ id: transaction.id });
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className={`w-5 h-5 ${upcomingTransactions.length > 0 ? 'text-orange-600' : 'text-gray-600'}`} />
          {upcomingTransactions.length > 0 && (
            <Badge 
              className={`absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-[10px] ${
                overdueCount > 0 ? 'bg-red-600' : 'bg-orange-600'
              }`}
            >
              {upcomingTransactions.length}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="border-b p-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Notificações</h3>
            <Badge variant="outline" className="text-xs">
              {upcomingTransactions.length} {upcomingTransactions.length === 1 ? 'alerta' : 'alertas'}
            </Badge>
          </div>
          {overdueCount > 0 && (
            <div className="flex items-center gap-2 mt-2 text-xs text-red-600">
              <AlertTriangle className="w-3 h-3" />
              <span>{overdueCount} {overdueCount === 1 ? 'conta atrasada' : 'contas atrasadas'}</span>
            </div>
          )}
        </div>

        <ScrollArea className="h-[400px]">
          {upcomingTransactions.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <Bell className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">Nenhuma notificação</p>
              <p className="text-xs text-gray-400 mt-1">Você está em dia!</p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              <AnimatePresence>
                {upcomingTransactions.map((transaction) => (
                  <motion.div
                    key={transaction.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className={`p-3 rounded-lg border-2 ${getPriorityColor(transaction.due_date)}`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="w-3 h-3 flex-shrink-0" />
                          <p className="font-medium text-sm truncate">{transaction.description}</p>
                        </div>
                        
                        <div className="flex flex-wrap items-center gap-2 text-xs mb-2">
                          <span>{format(new Date(transaction.due_date), "dd 'de' MMM", { locale: ptBR })}</span>
                          <Badge variant="outline" className="text-[10px] h-5 px-1">
                            {getPriorityLabel(transaction.due_date)}
                          </Badge>
                          {transaction.category_name && (
                            <Badge variant="secondary" className="text-[10px] h-5 px-1">
                              {transaction.category_icon} {transaction.category_name}
                            </Badge>
                          )}
                        </div>

                        <p className="font-bold text-sm">
                          {formatCurrency(transaction.amount)}
                        </p>
                      </div>

                      <Button
                        size="sm"
                        onClick={() => handleMarkAsPaid(transaction)}
                        disabled={markAsPaidMutation.isPending}
                        className={`h-8 text-xs flex-shrink-0 ${
                          transaction.type === 'receita' 
                            ? 'bg-green-600 hover:bg-green-700' 
                            : 'bg-blue-600 hover:bg-blue-700'
                        }`}
                      >
                        <CheckCircle className="w-3 h-3 mr-1" />
                        {transaction.type === 'receita' ? 'Receber' : 'Pagar'}
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}