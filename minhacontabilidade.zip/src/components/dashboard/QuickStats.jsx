import React from "react";
import { Card } from "@/components/ui/card";
import { CheckCircle, Clock, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

export default function QuickStats({ transactions }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const paidTransactions = transactions.filter(t => t.is_paid);
  const pendingTransactions = transactions.filter(t => !t.is_paid);
  
  const paidAmount = paidTransactions.reduce((sum, t) => 
    sum + (t.type === 'receita' ? t.amount : -t.amount), 0
  );
  
  const pendingAmount = pendingTransactions.reduce((sum, t) => 
    sum + (t.type === 'receita' ? t.amount : -t.amount), 0
  );

  const overdueCont = pendingTransactions.filter(t => {
    if (!t.due_date) return false;
    return new Date(t.due_date) < new Date();
  }).length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="p-4 bg-gradient-to-br from-green-50 to-green-100 border-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-200 rounded-xl">
              <CheckCircle className="w-6 h-6 text-green-700" />
            </div>
            <div>
              <p className="text-sm text-green-700 font-medium">Pagos/Recebidos</p>
              <p className="text-2xl font-bold text-green-900">{paidTransactions.length}</p>
              <p className="text-xs text-green-600">{formatCurrency(Math.abs(paidAmount))}</p>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-200 rounded-xl">
              <Clock className="w-6 h-6 text-blue-700" />
            </div>
            <div>
              <p className="text-sm text-blue-700 font-medium">Pendentes</p>
              <p className="text-2xl font-bold text-blue-900">{pendingTransactions.length}</p>
              <p className="text-xs text-blue-600">{formatCurrency(Math.abs(pendingAmount))}</p>
            </div>
          </div>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="p-4 bg-gradient-to-br from-red-50 to-red-100 border-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-red-200 rounded-xl">
              <AlertTriangle className="w-6 h-6 text-red-700" />
            </div>
            <div>
              <p className="text-sm text-red-700 font-medium">Em Atraso</p>
              <p className="text-2xl font-bold text-red-900">{overdueCont}</p>
              <p className="text-xs text-red-600">Requer atenção</p>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}