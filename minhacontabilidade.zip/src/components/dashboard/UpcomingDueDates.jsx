import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertCircle, Calendar, DollarSign } from "lucide-react";
import { differenceInDays, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";

export default function UpcomingDueDates({ transactions, onPayTransaction }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filter unpaid transactions with due dates in the next 7 days
  const today = new Date();
  const upcomingTransactions = transactions
    .filter(t => !t.is_paid && t.due_date)
    .map(t => {
      // Parse the date correctly (YYYY-MM-DD format)
      const dueDateParts = t.due_date.split('-');
      const dueDate = new Date(dueDateParts[0], dueDateParts[1] - 1, dueDateParts[2]);
      return {
        ...t,
        daysUntilDue: differenceInDays(dueDate, today)
      };
    })
    .filter(t => t.daysUntilDue >= -3 && t.daysUntilDue <= 7)
    .sort((a, b) => a.daysUntilDue - b.daysUntilDue);

  if (upcomingTransactions.length === 0) {
    return null;
  }

  const getUrgencyColor = (days) => {
    if (days < 0) return "bg-red-100 text-red-800 border-red-200";
    if (days === 0) return "bg-orange-100 text-orange-800 border-orange-200";
    if (days <= 3) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-blue-100 text-blue-800 border-blue-200";
  };

  const getUrgencyLabel = (days) => {
    if (days < 0) return `${Math.abs(days)} dias em atraso`;
    if (days === 0) return "Vence hoje";
    if (days === 1) return "Vence amanhã";
    return `Vence em ${days} dias`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Card className="border-0 shadow-lg bg-gradient-to-r from-orange-50 to-red-50">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-lg">
              <AlertCircle className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <CardTitle className="text-lg">Contas Próximas do Vencimento</CardTitle>
              <p className="text-sm text-gray-500">
                {upcomingTransactions.length} {upcomingTransactions.length === 1 ? 'conta' : 'contas'} para pagar
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <AnimatePresence>
            {upcomingTransactions.slice(0, 5).map((transaction, index) => (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white rounded-lg p-4 border border-gray-100 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <p className="font-medium text-gray-900 truncate">
                        {transaction.description}
                      </p>
                      {transaction.total_installments > 1 && (
                        <Badge variant="secondary" className="text-xs">
                          {transaction.installment_number}/{transaction.total_installments}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1 text-gray-600">
                        <Calendar className="w-3 h-3" />
                        <span>
                          {(() => {
                            const dueDateParts = transaction.due_date.split('-');
                            const dueDate = new Date(dueDateParts[0], dueDateParts[1] - 1, dueDateParts[2]);
                            return format(dueDate, "dd/MM/yyyy", { locale: ptBR });
                          })()}
                        </span>
                      </div>
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${getUrgencyColor(transaction.daysUntilDue)}`}
                      >
                        {getUrgencyLabel(transaction.daysUntilDue)}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <p className={`font-bold text-lg ${
                      transaction.type === 'receita' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {formatCurrency(transaction.amount)}
                    </p>
                    <Button
                      size="sm"
                      onClick={() => onPayTransaction(transaction)}
                      className="h-7 text-xs bg-green-600 hover:bg-green-700"
                    >
                      Marcar como Pago
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {upcomingTransactions.length > 5 && (
            <p className="text-sm text-gray-500 text-center pt-2">
              + {upcomingTransactions.length - 5} outras contas
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}