import React from "react";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import PrivateValue from "@/components/ui/PrivateValue";

export default function StatCard({ title, value, icon: Icon, color, trend, trendValue }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="relative overflow-hidden p-5 bg-white border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
        <div className={`absolute top-0 right-0 w-24 h-24 transform translate-x-8 -translate-y-8 rounded-full opacity-10 ${color}`} />
        
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">{title}</p>
            <PrivateValue value={value} className="text-2xl font-bold text-gray-900" />
            {trend && (
              <div className={`flex items-center gap-1 text-xs font-medium ${
                trend === 'up' ? 'text-green-600' : 'text-red-600'
              }`}>
                <span>{trend === 'up' ? '↑' : '↓'}</span>
                <span>{trendValue}</span>
              </div>
            )}
          </div>
          
          <div className={`p-3 rounded-xl ${color} bg-opacity-20`}>
            <Icon className={`w-6 h-6 ${color.replace('bg-', 'text-')}`} />
          </div>
        </div>
      </Card>
    </motion.div>
  );
}