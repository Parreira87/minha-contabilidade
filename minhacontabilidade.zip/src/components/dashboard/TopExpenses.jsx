import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingDown } from "lucide-react";
import { motion } from "framer-motion";

export default function TopExpenses({ transactions, categories }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Calculate expenses by category
  const expensesByCategory = {};
  transactions
    .filter(t => t.type === 'despesa')
    .forEach(t => {
      const catName = t.category_name || 'Outros';
      if (!expensesByCategory[catName]) {
        expensesByCategory[catName] = {
          total: 0,
          count: 0,
          categoryId: t.category_id
        };
      }
      expensesByCategory[catName].total += t.amount || 0;
      expensesByCategory[catName].count += 1;
    });

  // Sort and get top 10
  const topExpenses = Object.entries(expensesByCategory)
    .sort(([,a], [,b]) => b.total - a.total)
    .slice(0, 10)
    .map(([name, data]) => {
      const category = categories.find(c => c.name === name);
      return {
        name,
        total: data.total,
        count: data.count,
        color: category?.color || '#6b7280'
      };
    });

  const totalExpenses = transactions
    .filter(t => t.type === 'despesa')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  if (topExpenses.length === 0) {
    return null;
  }

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-red-100 rounded-lg">
            <TrendingDown className="w-5 h-5 text-red-600" />
          </div>
          <div>
            <CardTitle className="text-lg">Maiores Despesas por Categoria</CardTitle>
            <p className="text-sm text-gray-500">Onde você mais gasta seu dinheiro</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {topExpenses.map((expense, index) => {
          const percentage = totalExpenses > 0 ? (expense.total / totalExpenses * 100) : 0;
          
          return (
            <motion.div
              key={expense.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-lg p-4 border border-gray-100 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ backgroundColor: expense.color }}
                  >
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-gray-800">{expense.name}</p>
                    <p className="text-xs text-gray-500">
                      {expense.count} {expense.count === 1 ? 'lançamento' : 'lançamentos'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-red-600">{formatCurrency(expense.total)}</p>
                  <p className="text-xs text-gray-500">{percentage.toFixed(1)}%</p>
                </div>
              </div>
              
              {/* Progress bar */}
              <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${percentage}%` }}
                  transition={{ duration: 0.8, delay: index * 0.05 }}
                  className="h-full rounded-full"
                  style={{ backgroundColor: expense.color }}
                />
              </div>
            </motion.div>
          );
        })}

        {/* Total summary */}
        <div className="pt-3 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <p className="font-semibold text-gray-700">Total Geral de Despesas</p>
            <p className="font-bold text-xl text-red-600">{formatCurrency(totalExpenses)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}