import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, ArrowUpCircle, ArrowDownCircle, CheckCircle, Circle, Clock, Repeat } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import PrivateValue from "@/components/ui/PrivateValue";

export default function TransactionList({ transactions, onEdit, onDelete, onTogglePaid, onRepeat }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (dateStr) => {
    const [year, month, day] = dateStr.split('-');
    return format(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)), "dd MMM", { locale: ptBR });
  };

  const getDaysUntilDue = (dueDate) => {
    if (!dueDate) return null;
    const [year, month, day] = dueDate.split('-');
    const dueDateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return differenceInDays(dueDateObj, today);
  };

  const getDueStatus = (transaction) => {
    if (transaction.is_paid) return null;
    
    const days = getDaysUntilDue(transaction.due_date);
    if (days === null) return null;
    
    if (days < 0) return { label: `${Math.abs(days)}d atraso`, color: 'bg-red-100 text-red-700 border-red-200', blink: true };
    if (days === 0) return { label: 'Vence hoje', color: 'bg-orange-100 text-orange-700 border-orange-200', blink: true };
    if (days <= 3) return { label: `${days}d`, color: 'bg-yellow-100 text-yellow-700 border-yellow-200', blink: true };
    if (days <= 7) return { label: `${days}d`, color: 'bg-blue-100 text-blue-700 border-blue-200', blink: false };
    return null;
  };

  const getCardClass = (transaction) => {
    const status = getDueStatus(transaction);
    if (status?.blink) {
      return 'animate-pulse-soft';
    }
    return '';
  };

  return (
    <div className="space-y-3">
      <AnimatePresence>
        {transactions.map((transaction, index) => (
          <motion.div
            key={transaction.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card className={`p-3 md:p-4 border-0 shadow-sm hover:shadow-md transition-all ${
              transaction.is_paid ? 'bg-gray-50' : 'bg-white'
            } ${getCardClass(transaction)}`}>
              {/* Mobile Layout */}
              <div className="md:hidden space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <div className={`p-1.5 rounded-full flex-shrink-0 ${
                      transaction.type === 'receita' 
                        ? transaction.is_paid ? 'bg-green-100' : 'bg-green-50'
                        : transaction.is_paid ? 'bg-gray-200' : 'bg-red-100'
                    }`}>
                      {transaction.type === 'receita' ? (
                        <ArrowUpCircle className={`w-4 h-4 ${
                          transaction.is_paid ? 'text-green-600' : 'text-green-500'
                        }`} />
                      ) : (
                        <ArrowDownCircle className={`w-4 h-4 ${
                          transaction.is_paid ? 'text-gray-500' : 'text-red-600'
                        }`} />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <p className={`font-medium text-sm leading-tight ${
                        transaction.is_paid ? 'text-gray-500 line-through' : 'text-gray-800'
                      }`}>
                        {transaction.description}
                      </p>
                      {transaction.total_installments > 1 && (
                        <Badge variant="outline" className="text-xs mt-1">
                          {transaction.installment_number}/{transaction.total_installments}
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRepeat(transaction)}
                      className="h-7 w-7 text-gray-400 hover:text-purple-600"
                      title="Repetir no próximo mês"
                    >
                      <Repeat className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(transaction)}
                      className="h-7 w-7 text-gray-400 hover:text-blue-600"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(transaction.id)}
                      className="h-7 w-7 text-gray-400 hover:text-red-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  <div className="flex items-center gap-1 text-gray-500">
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(transaction.date)}</span>
                  </div>
                  {transaction.due_date && transaction.due_date !== transaction.date && (
                    <span className="text-gray-500">
                      → {formatDate(transaction.due_date)}
                    </span>
                  )}
                  {transaction.category_name && (
                    <Badge variant="secondary" className="text-xs flex items-center gap-1 h-5">
                      {transaction.category_icon && <span className="text-xs">{transaction.category_icon}</span>}
                      <span className="truncate max-w-[100px]">{transaction.category_name}</span>
                    </Badge>
                  )}
                  {getDueStatus(transaction) && (
                    <Badge variant="outline" className={`text-xs h-5 ${getDueStatus(transaction).color}`}>
                      {getDueStatus(transaction).label}
                    </Badge>
                  )}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                  <PrivateValue 
                    value={`${transaction.type === 'receita' ? '+' : '-'}${formatCurrency(transaction.amount)}`}
                    className={`font-bold text-base ${
                      transaction.is_paid 
                        ? 'text-gray-500' 
                        : transaction.type === 'receita' ? 'text-green-600' : 'text-red-600'
                    }`}
                  />
                  
                  <Button
                    size="sm"
                    onClick={() => onTogglePaid(transaction)}
                    className={`h-8 text-xs px-3 ${
                      transaction.is_paid 
                        ? 'bg-gray-400 hover:bg-gray-500' 
                        : transaction.type === 'receita'
                          ? 'bg-green-600 hover:bg-green-700'
                          : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {transaction.is_paid ? (
                      <>
                        <Circle className="w-3 h-3 mr-1" />
                        Desfazer
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-3 h-3 mr-1" />
                        {transaction.type === 'receita' ? 'Receber' : 'Pagar'}
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* Desktop Layout */}
              <div className="hidden md:flex items-start justify-between gap-3">
                <div className="flex items-start gap-4 flex-1 min-w-0">
                  <div className={`p-2 rounded-full flex-shrink-0 ${
                    transaction.type === 'receita' 
                      ? transaction.is_paid ? 'bg-green-100' : 'bg-green-50'
                      : transaction.is_paid ? 'bg-gray-200' : 'bg-red-100'
                  }`}>
                    {transaction.type === 'receita' ? (
                      <ArrowUpCircle className={`w-5 h-5 ${
                        transaction.is_paid ? 'text-green-600' : 'text-green-500'
                      }`} />
                    ) : (
                      <ArrowDownCircle className={`w-5 h-5 ${
                        transaction.is_paid ? 'text-gray-500' : 'text-red-600'
                      }`} />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className={`font-medium ${
                        transaction.is_paid ? 'text-gray-500 line-through' : 'text-gray-800'
                      }`}>
                        {transaction.description}
                      </p>
                      {transaction.total_installments > 1 && (
                        <Badge variant="outline" className="text-xs">
                          {transaction.installment_number}/{transaction.total_installments}
                        </Badge>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        <span>{formatDate(transaction.date)}</span>
                      </div>
                      {transaction.due_date && transaction.due_date !== transaction.date && (
                        <span className="text-xs text-gray-500">
                          → Venc: {formatDate(transaction.due_date)}
                        </span>
                      )}
                      {transaction.category_name && (
                        <Badge variant="secondary" className="text-xs flex items-center gap-1">
                          {transaction.category_icon && <span>{transaction.category_icon}</span>}
                          {transaction.category_name}
                        </Badge>
                      )}
                      {getDueStatus(transaction) && (
                        <Badge variant="outline" className={`text-xs ${getDueStatus(transaction).color}`}>
                          {getDueStatus(transaction).label}
                        </Badge>
                      )}
                      {transaction.is_paid && (
                        <Badge className="text-xs bg-green-100 text-green-700 border-green-200">
                          {transaction.type === 'receita' ? 'Recebido' : 'Pago'}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <PrivateValue 
                      value={`${transaction.type === 'receita' ? '+' : '-'}${formatCurrency(transaction.amount)}`}
                      className={`font-bold text-lg ${
                        transaction.is_paid 
                          ? 'text-gray-500' 
                          : transaction.type === 'receita' ? 'text-green-600' : 'text-red-600'
                      }`}
                    />
                    
                    <Button
                      size="sm"
                      onClick={() => onTogglePaid(transaction)}
                      className={`h-7 text-xs mt-2 ${
                        transaction.is_paid 
                          ? 'bg-gray-400 hover:bg-gray-500' 
                          : transaction.type === 'receita'
                            ? 'bg-green-600 hover:bg-green-700'
                            : 'bg-blue-600 hover:bg-blue-700'
                      }`}
                    >
                      {transaction.is_paid ? (
                        <>
                          <Circle className="w-3 h-3 mr-1" />
                          Desfazer
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          {transaction.type === 'receita' ? 'Receber' : 'Pagar'}
                        </>
                      )}
                    </Button>
                  </div>
                  
                  <div className="flex flex-col gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onRepeat(transaction)}
                      className="h-8 w-8 text-gray-500 hover:text-purple-600"
                      title="Repetir no próximo mês"
                    >
                      <Repeat className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(transaction)}
                      className="h-8 w-8 text-gray-500 hover:text-blue-600"
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(transaction.id)}
                      className="h-8 w-8 text-gray-500 hover:text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>

      {transactions.length === 0 && (
        <div className="text-center py-12 text-gray-500">
          <p>Nenhum lançamento encontrado</p>
        </div>
      )}
    </div>
  );
}