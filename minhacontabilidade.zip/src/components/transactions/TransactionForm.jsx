import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { X, Save, Sparkles, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const PAYMENT_METHODS = [
  { value: "dinheiro", label: "Dinheiro" },
  { value: "pix", label: "PIX" },
  { value: "cartao_credito", label: "Cartão de Crédito" },
  { value: "cartao_debito", label: "Cartão de Débito" },
  { value: "transferencia", label: "Transferência" },
  { value: "boleto", label: "Boleto" }
];

export default function TransactionForm({ isOpen, onClose, onSave, transaction, categories }) {
  const [suggestedCategory, setSuggestedCategory] = useState(null);
  const [formData, setFormData] = useState({
    type: "despesa",
    date: new Date().toISOString().split('T')[0],
    due_date: new Date().toISOString().split('T')[0],
    description: "",
    category_id: "",
    category_name: "",
    category_icon: "",
    amount: "",
    payment_method: "pix",
    notes: "",
    is_paid: false,
    installment_number: "",
    total_installments: "",
    repeat_next_month: false
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (transaction) {
      setFormData({
        type: transaction.type || "despesa",
        date: transaction.date || new Date().toISOString().split('T')[0],
        due_date: transaction.due_date || new Date().toISOString().split('T')[0],
        description: transaction.description || "",
        category_id: transaction.category_id || "",
        category_name: transaction.category_name || "",
        category_icon: transaction.category_icon || "",
        amount: transaction.amount?.toString() || "",
        payment_method: transaction.payment_method || "pix",
        notes: transaction.notes || "",
        is_paid: transaction.is_paid || false,
        installment_number: transaction.installment_number?.toString() || "",
        total_installments: transaction.total_installments?.toString() || "",
        repeat_next_month: false
      });
    } else {
      setFormData({
        type: "despesa",
        date: new Date().toISOString().split('T')[0],
        due_date: new Date().toISOString().split('T')[0],
        description: "",
        category_id: "",
        category_name: "",
        category_icon: "",
        amount: "",
        payment_method: "pix",
        notes: "",
        is_paid: false,
        installment_number: "",
        total_installments: "",
        repeat_next_month: false
      });
    }
  }, [transaction, isOpen]);

  const handleCategoryChange = (categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    setFormData({
      ...formData,
      category_id: categoryId,
      category_name: category?.name || "",
      category_icon: category?.icon || ""
    });
    setSuggestedCategory(null);
  };

  const handleDescriptionChange = async (description) => {
    setFormData({ ...formData, description });
    
    if (description.length > 3 && !transaction) {
      // Get historical transactions with similar descriptions (user's own data only)
      const user = await base44.auth.me();
      const allTransactions = await base44.entities.Transaction.filter({ created_by: user.email });
      
      const matches = allTransactions
        .filter(t => 
          t.type === formData.type &&
          t.description && 
          t.description.toLowerCase().includes(description.toLowerCase().trim())
        )
        .slice(0, 5);

      if (matches.length > 0) {
        // Find most common category
        const categoryCount = {};
        matches.forEach(t => {
          if (t.category_id) {
            categoryCount[t.category_id] = (categoryCount[t.category_id] || 0) + 1;
          }
        });
        
        const mostCommonCategoryId = Object.keys(categoryCount).reduce((a, b) => 
          categoryCount[a] > categoryCount[b] ? a : b
        );
        
        const category = categories.find(c => c.id === mostCommonCategoryId);
        if (category) {
          setSuggestedCategory(category);
        }
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const data = {
      ...formData,
      amount: parseFloat(formData.amount) || 0,
      installment_number: formData.installment_number ? parseInt(formData.installment_number) : undefined,
      total_installments: formData.total_installments ? parseInt(formData.total_installments) : undefined
    };
    delete data.repeat_next_month;

    if (transaction?.id) {
      await base44.entities.Transaction.update(transaction.id, data);
    } else {
      await base44.entities.Transaction.create(data);
      
      // Se repeat_next_month estiver marcado, criar lançamento para próximo mês
      if (formData.repeat_next_month) {
        const nextMonthDate = new Date(formData.date);
        nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
        
        const nextMonthDueDate = new Date(formData.due_date);
        nextMonthDueDate.setMonth(nextMonthDueDate.getMonth() + 1);
        
        await base44.entities.Transaction.create({
          ...data,
          date: nextMonthDate.toISOString().split('T')[0],
          due_date: nextMonthDueDate.toISOString().split('T')[0]
        });
      }
    }
    
    setIsLoading(false);
    setShowSuccess(true);
    
    setTimeout(() => {
      setShowSuccess(false);
      onSave();
      onClose();
    }, 1000);
  };

  const filteredCategories = categories.filter(c => c.type === formData.type);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-white/95 backdrop-blur-sm rounded-lg"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center"
                >
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </motion.div>
                <p className="text-xl font-bold text-gray-800">Salvo com sucesso!</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-800">
            {transaction ? "Editar Lançamento" : "Novo Lançamento"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant={formData.type === "receita" ? "default" : "outline"}
              className={formData.type === "receita" ? "bg-green-600 hover:bg-green-700" : ""}
              onClick={() => setFormData({ ...formData, type: "receita", category_id: "", category_name: "", category_icon: "" })}
            >
              Receita
            </Button>
            <Button
              type="button"
              variant={formData.type === "despesa" ? "default" : "outline"}
              className={formData.type === "despesa" ? "bg-red-600 hover:bg-red-700" : ""}
              onClick={() => setFormData({ ...formData, type: "despesa", category_id: "", category_name: "", category_icon: "" })}
            >
              Despesa
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Data Lançamento</Label>
              <Input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Data Vencimento</Label>
              <Input
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Descrição</Label>
            <Input
              placeholder="Ex: Conta de luz"
              value={formData.description}
              onChange={(e) => handleDescriptionChange(e.target.value)}
              required
            />
            {suggestedCategory && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 p-2 bg-purple-50 border border-purple-200 rounded-lg"
              >
                <Sparkles className="w-4 h-4 text-purple-600" />
                <span className="text-sm text-gray-700">Sugestão:</span>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-7 text-xs"
                  onClick={() => handleCategoryChange(suggestedCategory.id)}
                >
                  <div className="flex items-center gap-1">
                    {suggestedCategory.icon && <span>{suggestedCategory.icon}</span>}
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: suggestedCategory.color }} />
                    {suggestedCategory.name}
                  </div>
                </Button>
              </motion.div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Categoria</Label>
            <Select value={formData.category_id} onValueChange={handleCategoryChange}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {filteredCategories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    <div className="flex items-center gap-2">
                      {cat.icon && <span className="text-base">{cat.icon}</span>}
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Valor (R$)</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Forma de Pagamento</Label>
            <Select value={formData.payment_method} onValueChange={(v) => setFormData({ ...formData, payment_method: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Parcela Atual</Label>
              <Input
                type="number"
                min="1"
                placeholder="Ex: 1"
                value={formData.installment_number}
                onChange={(e) => setFormData({ ...formData, installment_number: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Total de Parcelas</Label>
              <Input
                type="number"
                min="1"
                placeholder="Ex: 12"
                value={formData.total_installments}
                onChange={(e) => setFormData({ ...formData, total_installments: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Observações</Label>
            <Textarea
              placeholder="Observações adicionais..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={2}
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <Label>Já foi {formData.type === "receita" ? "recebido" : "pago"}?</Label>
            <Switch
              checked={formData.is_paid}
              onCheckedChange={(checked) => setFormData({ ...formData, is_paid: checked })}
            />
          </div>

          {!transaction && (
            <div className="flex items-center justify-between py-2 bg-blue-50 px-3 rounded-lg">
              <div>
                <Label>Repetir para o próximo mês</Label>
                <p className="text-xs text-gray-500">Cria automaticamente o mesmo lançamento no próximo mês</p>
              </div>
              <Switch
                checked={formData.repeat_next_month}
                onCheckedChange={(checked) => setFormData({ ...formData, repeat_next_month: checked })}
              />
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-blue-900 hover:bg-blue-800">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}