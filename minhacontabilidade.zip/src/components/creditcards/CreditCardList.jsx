import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Pencil, Trash2, Plus, CreditCard as CreditCardIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function CreditCardList({ cards, expenses, onEdit, onAddExpense }) {
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CreditCard.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['credit-cards'] });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este cartão?')) {
      deleteMutation.mutate(id);
    }
  };

  const getCardExpenses = (cardId) => {
    return expenses.filter(e => e.card_id === cardId);
  };

  const getCurrentMonthExpense = (cardId) => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const currentMonth = `${year}-${month}`;
    const expense = expenses.find(e => e.card_id === cardId && e.month === currentMonth);
    return expense?.amount || 0;
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-gray-800">Meus Cartões</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <AnimatePresence>
          {cards.map((card, index) => {
            const currentExpense = getCurrentMonthExpense(card.id);
            const usagePercent = card.limit ? (currentExpense / card.limit) * 100 : 0;

            return (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card 
                  className="border-0 shadow-lg overflow-hidden"
                  style={{ 
                    background: `linear-gradient(135deg, ${card.color || '#3b82f6'} 0%, ${card.color || '#3b82f6'}dd 100%)`
                  }}
                >
                  <CardHeader className="text-white pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <CreditCardIcon className="w-5 h-5" />
                          <CardTitle className="text-lg">{card.name}</CardTitle>
                        </div>
                        {card.last_digits && (
                          <p className="text-white/80 text-sm">**** **** **** {card.last_digits}</p>
                        )}
                        {card.bank && (
                          <p className="text-white/70 text-xs mt-1">{card.bank}</p>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(card)}
                          className="h-8 w-8 text-white hover:bg-white/20"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(card.id)}
                          className="h-8 w-8 text-white hover:bg-white/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="bg-white">
                    <div className="space-y-3">
                      {card.limit && (
                        <>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-500">Limite</span>
                            <span className="font-bold text-gray-800">{formatCurrency(card.limit)}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-500">Fatura Atual</span>
                            <span className="font-bold text-orange-600">{formatCurrency(currentExpense)}</span>
                          </div>
                          <div>
                            <div className="flex justify-between text-xs text-gray-500 mb-1">
                              <span>Utilizado</span>
                              <span>{usagePercent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full transition-all ${
                                  usagePercent > 80 ? 'bg-red-500' : usagePercent > 50 ? 'bg-orange-500' : 'bg-green-500'
                                }`}
                                style={{ width: `${Math.min(100, usagePercent)}%` }}
                              />
                            </div>
                          </div>
                        </>
                      )}
                      <div className="flex justify-between text-xs text-gray-500 pt-2 border-t">
                        <span>Fecha dia {card.closing_day}</span>
                        <span>Vence dia {card.due_day}</span>
                      </div>
                      <Button 
                        onClick={() => onAddExpense(card)}
                        className="w-full"
                        size="sm"
                        style={{ backgroundColor: card.color || '#3b82f6' }}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Lançar Fatura
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
      {cards.length === 0 && (
        <Card className="border-0 shadow-lg">
          <CardContent className="py-12 text-center text-gray-500">
            <CreditCardIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Nenhum cartão cadastrado</p>
            <p className="text-sm mt-2">Comece adicionando seu primeiro cartão</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}