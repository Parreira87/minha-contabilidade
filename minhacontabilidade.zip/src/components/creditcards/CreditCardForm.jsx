import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { X, Save, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const COLORS = [
  "#3b82f6", "#8b5cf6", "#ec4899", "#f59e0b", 
  "#10b981", "#ef4444", "#6366f1", "#14b8a6"
];

export default function CreditCardForm({ isOpen, onClose, card }) {
  const [formData, setFormData] = useState({
    name: "",
    last_digits: "",
    limit: "",
    closing_day: "",
    due_day: "",
    bank: "",
    color: COLORS[0],
    is_active: true
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (card) {
      setFormData({
        name: card.name || "",
        last_digits: card.last_digits || "",
        limit: card.limit?.toString() || "",
        closing_day: card.closing_day?.toString() || "",
        due_day: card.due_day?.toString() || "",
        bank: card.bank || "",
        color: card.color || COLORS[0],
        is_active: card.is_active !== undefined ? card.is_active : true
      });
    } else {
      setFormData({
        name: "",
        last_digits: "",
        limit: "",
        closing_day: "",
        due_day: "",
        bank: "",
        color: COLORS[0],
        is_active: true
      });
    }
  }, [card, isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const data = {
      ...formData,
      limit: formData.limit ? parseFloat(formData.limit) : undefined,
      closing_day: parseInt(formData.closing_day),
      due_day: parseInt(formData.due_day)
    };

    if (card?.id) {
      await base44.entities.CreditCard.update(card.id, data);
    } else {
      await base44.entities.CreditCard.create(data);
    }
    
    setIsLoading(false);
    setShowSuccess(true);
    
    setTimeout(() => {
      setShowSuccess(false);
      queryClient.invalidateQueries({ queryKey: ['credit-cards'] });
      onClose();
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-white/95 backdrop-blur-sm rounded-lg"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center"
                >
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </motion.div>
                <p className="text-xl font-bold text-gray-800">Salvo com sucesso!</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <DialogHeader>
          <DialogTitle>{card ? "Editar Cartão" : "Novo Cartão de Crédito"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Nome do Cartão *</Label>
            <Input
              placeholder="Ex: Nubank Mastercard"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Últimos 4 dígitos</Label>
              <Input
                placeholder="1234"
                maxLength={4}
                value={formData.last_digits}
                onChange={(e) => setFormData({ ...formData, last_digits: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Banco</Label>
              <Input
                placeholder="Ex: Nubank"
                value={formData.bank}
                onChange={(e) => setFormData({ ...formData, bank: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Limite do Cartão</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={formData.limit}
              onChange={(e) => setFormData({ ...formData, limit: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Dia Fechamento *</Label>
              <Input
                type="number"
                min="1"
                max="31"
                placeholder="Ex: 15"
                value={formData.closing_day}
                onChange={(e) => setFormData({ ...formData, closing_day: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Dia Vencimento *</Label>
              <Input
                type="number"
                min="1"
                max="31"
                placeholder="Ex: 25"
                value={formData.due_day}
                onChange={(e) => setFormData({ ...formData, due_day: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Cor do Cartão</Label>
            <div className="flex gap-2">
              {COLORS.map(color => (
                <button
                  key={color}
                  type="button"
                  className={`w-10 h-10 rounded-lg transition-all ${
                    formData.color === color ? 'ring-2 ring-offset-2 ring-blue-500 scale-110' : ''
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => setFormData({ ...formData, color })}
                />
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between py-2">
            <Label>Cartão Ativo?</Label>
            <Switch
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}