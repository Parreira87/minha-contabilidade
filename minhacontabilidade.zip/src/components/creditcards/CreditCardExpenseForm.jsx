import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { X, Save, CheckCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function CreditCardExpenseForm({ isOpen, onClose, cards, selectedCard, expense }) {
  const getCurrentMonth = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };

  const [formData, setFormData] = useState({
    card_id: "",
    card_name: "",
    month: getCurrentMonth(),
    amount: "",
    description: "",
    is_paid: false,
    payment_date: ""
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (expense) {
      setFormData({
        card_id: expense.card_id,
        card_name: expense.card_name,
        month: expense.month,
        amount: expense.amount.toString(),
        description: expense.description || "",
        is_paid: expense.is_paid || false,
        payment_date: expense.payment_date || ""
      });
    } else if (selectedCard) {
      setFormData(prev => ({
        ...prev,
        card_id: selectedCard.id,
        card_name: selectedCard.name
      }));
    }
  }, [selectedCard, expense]);

  useEffect(() => {
    if (!isOpen) {
      setFormData({
        card_id: "",
        card_name: "",
        month: getCurrentMonth(),
        amount: "",
        description: "",
        is_paid: false,
        payment_date: ""
      });
    }
  }, [isOpen]);

  const handleCardChange = (cardId) => {
    const card = cards.find(c => c.id === cardId);
    setFormData({
      ...formData,
      card_id: cardId,
      card_name: card?.name || ""
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const data = {
      ...formData,
      amount: parseFloat(formData.amount) || 0,
      payment_date: formData.payment_date || undefined
    };

    if (expense) {
      await base44.entities.CreditCardExpense.update(expense.id, data);
    } else {
      await base44.entities.CreditCardExpense.create(data);
    }
    
    setIsLoading(false);
    setShowSuccess(true);
    
    setTimeout(() => {
      setShowSuccess(false);
      queryClient.invalidateQueries({ queryKey: ['credit-card-expenses'] });
      onClose();
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <AnimatePresence>
          {showSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 z-50 flex items-center justify-center bg-white/95 backdrop-blur-sm rounded-lg"
            >
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-20 h-20 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center"
                >
                  <CheckCircle className="w-12 h-12 text-green-600" />
                </motion.div>
                <p className="text-xl font-bold text-gray-800">Fatura lançada!</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <DialogHeader>
          <DialogTitle>{expense ? 'Editar Fatura' : 'Lançar Fatura do Cartão'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Cartão *</Label>
            <Select 
              value={formData.card_id} 
              onValueChange={handleCardChange}
              disabled={!!selectedCard || !!expense}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o cartão" />
              </SelectTrigger>
              <SelectContent>
                {cards.filter(c => c.is_active).map(card => (
                  <SelectItem key={card.id} value={card.id}>
                    {card.name} {card.last_digits && `(****${card.last_digits})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Mês da Fatura *</Label>
            <Input
              type="month"
              value={formData.month}
              onChange={(e) => setFormData({ ...formData, month: e.target.value })}
              min="2026-01"
              max="2027-12"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Valor da Fatura (R$) *</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              placeholder="0,00"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Descrição</Label>
            <Textarea
              placeholder="Descrição dos gastos..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <Label>Já foi pago?</Label>
            <Switch
              checked={formData.is_paid}
              onCheckedChange={(checked) => setFormData({ ...formData, is_paid: checked })}
            />
          </div>

          {formData.is_paid && (
            <div className="space-y-2">
              <Label>Data do Pagamento</Label>
              <Input
                type="date"
                value={formData.payment_date}
                onChange={(e) => setFormData({ ...formData, payment_date: e.target.value })}
              />
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-blue-600 hover:bg-blue-700">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}