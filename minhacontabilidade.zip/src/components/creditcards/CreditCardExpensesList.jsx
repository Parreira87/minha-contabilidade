import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { CheckCircle, Circle, Trash2, Pencil } from "lucide-react";

export default function CreditCardExpensesList({ expenses, cards, onEdit }) {
  const [selectedMonth, setSelectedMonth] = useState("all");
  const queryClient = useQueryClient();

  const togglePaidMutation = useMutation({
    mutationFn: ({ id, is_paid }) => base44.entities.CreditCardExpense.update(id, { 
      is_paid,
      payment_date: is_paid ? new Date().toISOString().split('T')[0] : undefined
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['credit-card-expenses'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CreditCardExpense.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['credit-card-expenses'] });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getCardColor = (cardId) => {
    return cards.find(c => c.id === cardId)?.color || '#3b82f6';
  };

  const filteredExpenses = selectedMonth === "all" 
    ? expenses 
    : expenses.filter(e => e.month === selectedMonth);

  const uniqueMonths = [...new Set(expenses.map(e => e.month))].sort().reverse();

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta fatura?')) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Histórico de Faturas</CardTitle>
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Meses</SelectItem>
              {uniqueMonths.map(month => {
                const [year, monthNum] = month.split('-');
                return (
                  <SelectItem key={month} value={month}>
                    {format(new Date(parseInt(year), parseInt(monthNum) - 1, 1), 'MMMM yyyy', { locale: ptBR })}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {filteredExpenses.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            Nenhuma fatura lançada
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[150px]">Cartão</TableHead>
                <TableHead className="min-w-[120px]">Mês</TableHead>
                <TableHead className="min-w-[120px]">Valor</TableHead>
                <TableHead className="min-w-[140px]">Status</TableHead>
                <TableHead className="text-right min-w-[120px]">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredExpenses.map((expense) => {
                const cardColor = getCardColor(expense.card_id);
                return (
                  <TableRow key={expense.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: cardColor }}
                        />
                        <span className="font-medium">{expense.card_name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {(() => {
                        const [year, month] = expense.month.split('-');
                        return format(new Date(parseInt(year), parseInt(month) - 1, 1), 'MMM yyyy', { locale: ptBR });
                      })()}
                    </TableCell>
                    <TableCell className="font-bold text-orange-600">
                      {formatCurrency(expense.amount)}
                    </TableCell>
                    <TableCell>
                      <Button
                        size="sm"
                        variant={expense.is_paid ? "default" : "outline"}
                        onClick={() => togglePaidMutation.mutate({ 
                          id: expense.id, 
                          is_paid: !expense.is_paid 
                        })}
                        className={expense.is_paid ? "bg-green-600 hover:bg-green-700" : ""}
                      >
                        {expense.is_paid ? (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Pago
                          </>
                        ) : (
                          <>
                            <Circle className="w-4 h-4 mr-2" />
                            Pendente
                          </>
                        )}
                      </Button>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(expense)}
                          className="text-gray-400 hover:text-blue-600"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(expense.id)}
                          className="text-gray-400 hover:text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}