import React, { useState, useEffect } from "react";

export default function PrivateValue({ value, className = "", type = "text" }) {
  const [isPrivate, setIsPrivate] = useState(false);

  useEffect(() => {
    const updatePrivateMode = () => {
      setIsPrivate(window.privateModeEnabled || false);
    };

    updatePrivateMode();
    window.addEventListener('privateModeChanged', updatePrivateMode);
    return () => window.removeEventListener('privateModeChanged', updatePrivateMode);
  }, []);

  if (!isPrivate) {
    return <span className={className}>{value}</span>;
  }

  // Máscaras diferentes por tipo
  const getMaskedValue = () => {
    if (type === "currency") {
      return "R$ ••••,••";
    }
    if (type === "number") {
      return "•••";
    }
    if (type === "date") {
      return "••/••/••••";
    }
    // Para texto genérico
    const length = value?.toString().length || 8;
    return "•".repeat(Math.min(length, 12));
  };

  return (
    <span className={`${className} select-none text-purple-600 font-medium`}>
      {getMaskedValue()}
    </span>
  );
}