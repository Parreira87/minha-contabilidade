import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";
import { X, Save, Repeat } from "lucide-react";

const PAYMENT_METHODS = [
  { value: "dinheiro", label: "Dinheiro" },
  { value: "pix", label: "PIX" },
  { value: "cartao_credito", label: "Cartão de Crédito" },
  { value: "cartao_debito", label: "Cartão de Débito" },
  { value: "transferencia", label: "Transferência" },
  { value: "boleto", label: "Boleto" }
];

const FREQUENCIES = [
  { value: "semanal", label: "Semanal" },
  { value: "quinzenal", label: "Quinzenal" },
  { value: "mensal", label: "Mensal" },
  { value: "trimestral", label: "Trimestral" },
  { value: "semestral", label: "Semestral" },
  { value: "anual", label: "Anual" }
];

export default function RecurringForm({ isOpen, onClose, onSave, recurring, categories }) {
  const [formData, setFormData] = useState({
    type: "despesa",
    description: "",
    category_id: "",
    category_name: "",
    amount: "",
    payment_method: "pix",
    frequency: "mensal",
    day_of_month: "5",
    start_date: new Date().toISOString().split('T')[0],
    end_date: "",
    is_active: true,
    auto_confirm: false,
    notes: ""
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (recurring) {
      setFormData({
        type: recurring.type || "despesa",
        description: recurring.description || "",
        category_id: recurring.category_id || "",
        category_name: recurring.category_name || "",
        amount: recurring.amount?.toString() || "",
        payment_method: recurring.payment_method || "pix",
        frequency: recurring.frequency || "mensal",
        day_of_month: recurring.day_of_month?.toString() || "5",
        start_date: recurring.start_date || new Date().toISOString().split('T')[0],
        end_date: recurring.end_date || "",
        is_active: recurring.is_active !== undefined ? recurring.is_active : true,
        auto_confirm: recurring.auto_confirm || false,
        notes: recurring.notes || ""
      });
    } else {
      setFormData({
        type: "despesa",
        description: "",
        category_id: "",
        category_name: "",
        amount: "",
        payment_method: "pix",
        frequency: "mensal",
        day_of_month: "5",
        start_date: new Date().toISOString().split('T')[0],
        end_date: "",
        is_active: true,
        auto_confirm: false,
        notes: ""
      });
    }
  }, [recurring, isOpen]);

  const handleCategoryChange = (categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    setFormData({
      ...formData,
      category_id: categoryId,
      category_name: category?.name || ""
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const data = {
      ...formData,
      amount: parseFloat(formData.amount) || 0,
      day_of_month: parseInt(formData.day_of_month) || 5
    };

    if (recurring?.id) {
      await base44.entities.RecurringTransaction.update(recurring.id, data);
    } else {
      await base44.entities.RecurringTransaction.create(data);
    }
    
    setIsLoading(false);
    onSave();
    onClose();
  };

  const filteredCategories = categories.filter(c => c.type === formData.type);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-bold text-gray-800">
            <Repeat className="w-5 h-5 text-purple-600" />
            {recurring ? "Editar Recorrência" : "Nova Recorrência"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant={formData.type === "receita" ? "default" : "outline"}
              className={formData.type === "receita" ? "bg-green-600 hover:bg-green-700" : ""}
              onClick={() => setFormData({ ...formData, type: "receita", category_id: "", category_name: "" })}
            >
              Receita
            </Button>
            <Button
              type="button"
              variant={formData.type === "despesa" ? "default" : "outline"}
              className={formData.type === "despesa" ? "bg-red-600 hover:bg-red-700" : ""}
              onClick={() => setFormData({ ...formData, type: "despesa", category_id: "", category_name: "" })}
            >
              Despesa
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Descrição</Label>
            <Input
              placeholder="Ex: Aluguel, Salário..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Categoria</Label>
            <Select value={formData.category_id} onValueChange={handleCategoryChange}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {filteredCategories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Valor (R$)</Label>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Dia do Mês</Label>
              <Input
                type="number"
                min="1"
                max="31"
                value={formData.day_of_month}
                onChange={(e) => setFormData({ ...formData, day_of_month: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Frequência</Label>
            <Select value={formData.frequency} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FREQUENCIES.map((freq) => (
                  <SelectItem key={freq.value} value={freq.value}>
                    {freq.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Forma de Pagamento</Label>
            <Select value={formData.payment_method} onValueChange={(v) => setFormData({ ...formData, payment_method: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((method) => (
                  <SelectItem key={method.value} value={method.value}>
                    {method.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Data Início</Label>
              <Input
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Data Fim (Opcional)</Label>
              <Input
                type="date"
                value={formData.end_date}
                onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
              />
            </div>
          </div>

          <div className="flex items-center justify-between py-2 border-t border-gray-100">
            <Label>Confirmar Automaticamente</Label>
            <Switch
              checked={formData.auto_confirm}
              onCheckedChange={(checked) => setFormData({ ...formData, auto_confirm: checked })}
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <Label>Ativa</Label>
            <Switch
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="flex-1 bg-purple-600 hover:bg-purple-700">
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}