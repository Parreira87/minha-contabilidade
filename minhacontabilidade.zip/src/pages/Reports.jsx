import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, startOfMonth, endOfMonth, isWithinInterval, eachMonthOfInterval } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ArrowLeft, FileText, FileDown, FileSpreadsheet, Calendar } from "lucide-react";
import CategoryPieChart from "@/components/dashboard/CategoryPieChart";
import BalanceLineChart from "@/components/reports/BalanceLineChart";
import ExpenseBarChart from "@/components/reports/ExpenseBarChart";
import DateRangeFilter from "@/components/reports/DateRangeFilter";
import { motion } from "framer-motion";

const MONTHS = [
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

export default function Reports() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth().toString());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [dateRange, setDateRange] = useState({
    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
    preset: "current_month"
  });
  const [useCustomRange, setUseCustomRange] = useState(false);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Transaction.filter({ created_by: user.email }, '-date');
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: user.email });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filter transactions for selected period
  const filteredTransactions = transactions.filter(t => {
    if (useCustomRange) {
      const date = new Date(t.date);
      return isWithinInterval(date, {
        start: new Date(dateRange.startDate),
        end: new Date(dateRange.endDate)
      });
    } else {
      const date = new Date(t.date);
      return date.getMonth().toString() === selectedMonth && 
             date.getFullYear().toString() === selectedYear;
    }
  });

  const totalIncome = filteredTransactions
    .filter(t => t.type === 'receita')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === 'despesa')
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  // Group by category
  const expensesByCategory = {};
  filteredTransactions
    .filter(t => t.type === 'despesa')
    .forEach(t => {
      const catName = t.category_name || 'Outros';
      if (!expensesByCategory[catName]) {
        expensesByCategory[catName] = { total: 0, count: 0 };
      }
      expensesByCategory[catName].total += t.amount || 0;
      expensesByCategory[catName].count += 1;
    });

  const incomeByCategory = {};
  filteredTransactions
    .filter(t => t.type === 'receita')
    .forEach(t => {
      const catName = t.category_name || 'Outros';
      if (!incomeByCategory[catName]) {
        incomeByCategory[catName] = { total: 0, count: 0 };
      }
      incomeByCategory[catName].total += t.amount || 0;
      incomeByCategory[catName].count += 1;
    });

  const categoryChartData = Object.entries(expensesByCategory)
    .map(([name, data]) => {
      const cat = categories.find(c => c.name === name);
      return { name, value: data.total, color: cat?.color };
    })
    .sort((a, b) => b.value - a.value);

  // Generate monthly data for line/bar charts
  const generateMonthlyData = () => {
    const months = useCustomRange
      ? eachMonthOfInterval({
          start: new Date(dateRange.startDate),
          end: new Date(dateRange.endDate)
        })
      : eachMonthOfInterval({
          start: new Date(parseInt(selectedYear), 0, 1),
          end: new Date(parseInt(selectedYear), 11, 31)
        });

    return months.map(month => {
      const monthTransactions = transactions.filter(t => {
        const date = new Date(t.date);
        return date.getMonth() === month.getMonth() && 
               date.getFullYear() === month.getFullYear();
      });

      const income = monthTransactions
        .filter(t => t.type === 'receita')
        .reduce((sum, t) => sum + (t.amount || 0), 0);

      const expense = monthTransactions
        .filter(t => t.type === 'despesa')
        .reduce((sum, t) => sum + (t.amount || 0), 0);

      return {
        month: format(month, 'MMM', { locale: ptBR }),
        income,
        expense,
        balance: income - expense
      };
    });
  };

  const monthlyData = generateMonthlyData();

  const monthName = MONTHS.find(m => m.value === selectedMonth)?.label;

  const handleGeneratePDF = async (type = 'all') => {
    setIsGeneratingPDF(true);
    
    const response = await base44.functions.invoke('generateReport', {
      month: selectedMonth,
      year: selectedYear,
      type
    });

    const blob = new Blob([response.data], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const typeLabel = type === 'receita' ? 'receitas' : type === 'despesa' ? 'despesas' : 'completo';
    a.download = `relatorio-${typeLabel}-${monthName}-${selectedYear}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    
    setIsGeneratingPDF(false);
  };

  const handleGenerateNotesReport = (type) => {
    const txs = filteredTransactions.filter(t => t.type === type);
    const typeLabel = type === 'receita' ? 'RECEITAS' : 'DESPESAS';
    
    const periodLabel = useCustomRange
      ? `${format(new Date(dateRange.startDate), 'dd/MM/yyyy')} - ${format(new Date(dateRange.endDate), 'dd/MM/yyyy')}`
      : `${monthName} ${selectedYear}`;
    
    let content = `===========================================\n`;
    content += `RELATÓRIO DE OBSERVAÇÕES - ${typeLabel}\n`;
    content += `${periodLabel}\n`;
    content += `===========================================\n\n`;
    
    if (txs.length === 0) {
      content += `Nenhuma ${type === 'receita' ? 'receita' : 'despesa'} encontrada neste período.\n`;
    } else {
      txs.forEach((tx, index) => {
        content += `${index + 1}. ${tx.description}\n`;
        const [year, month, day] = tx.date.split('-');
        const dateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
        content += `   Data: ${format(dateObj, 'dd/MM/yyyy', { locale: ptBR })}\n`;
        content += `   Valor: ${formatCurrency(tx.amount)}\n`;
        content += `   Categoria: ${tx.category_name || 'Sem categoria'}\n`;
        content += `   Status: ${tx.is_paid ? (type === 'receita' ? 'Recebido' : 'Pago') : 'Pendente'}\n`;
        
        if (tx.notes && tx.notes.trim()) {
          content += `   OBSERVAÇÕES:\n`;
          content += `   ${tx.notes.split('\n').join('\n   ')}\n`;
        } else {
          content += `   OBSERVAÇÕES: Nenhuma observação registrada\n`;
        }
        
        content += `\n-------------------------------------------\n\n`;
      });
      
      const total = txs.reduce((sum, t) => sum + (t.amount || 0), 0);
      content += `\nTOTAL: ${formatCurrency(total)}\n`;
      content += `Total de ${type === 'receita' ? 'receitas' : 'despesas'}: ${txs.length}\n`;
    }
    
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileName = useCustomRange
      ? `observacoes-${type === 'receita' ? 'receitas' : 'despesas'}-${format(new Date(dateRange.startDate), 'yyyy-MM-dd')}-${format(new Date(dateRange.endDate), 'yyyy-MM-dd')}.txt`
      : `observacoes-${type === 'receita' ? 'receitas' : 'despesas'}-${monthName}-${selectedYear}.txt`;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const generateCSV = () => {
    const headers = ['Data', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Forma de Pagamento', 'Status', 'Observações'];
    const rows = filteredTransactions.map(t => {
      const [year, month, day] = t.date.split('-');
      const dateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      return [
        format(dateObj, 'dd/MM/yyyy'),
        t.type === 'receita' ? 'Receita' : 'Despesa',
        t.description,
        t.category_name || '',
        t.amount.toFixed(2).replace('.', ','),
        t.payment_method || '',
        t.is_paid ? 'Pago' : 'Pendente',
        (t.notes || '').replace(/"/g, '""')
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileName = useCustomRange
      ? `relatorio-${format(new Date(dateRange.startDate), 'yyyy-MM-dd')}-${format(new Date(dateRange.endDate), 'yyyy-MM-dd')}.csv`
      : `relatorio-${monthName}-${selectedYear}.csv`;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-orange-100 rounded-xl">
                <FileText className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Relatórios</h1>
                <p className="text-gray-500">Análise detalhada das suas finanças</p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {!useCustomRange ? (
              <>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-36 bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {MONTHS.map(month => (
                      <SelectItem key={month.value} value={month.value}>
                        {month.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger className="w-24 bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map(year => (
                      <SelectItem key={year} value={year}>{year}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </>
            ) : (
              <div className="flex items-center gap-2 text-sm text-gray-600 bg-white px-4 py-2 rounded-lg border">
                <Calendar className="w-4 h-4" />
                {format(new Date(dateRange.startDate), 'dd/MM/yyyy')} - {format(new Date(dateRange.endDate), 'dd/MM/yyyy')}
              </div>
            )}

            <DateRangeFilter onApply={(range) => {
              setDateRange(range);
              setUseCustomRange(true);
            }} />

            {useCustomRange && (
              <Button 
                variant="outline"
                onClick={() => {
                  setUseCustomRange(false);
                  setDateRange({
                    startDate: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
                    endDate: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
                    preset: "current_month"
                  });
                }}
              >
                Voltar ao Mês
              </Button>
            )}

            <Button 
              onClick={() => generateCSV()}
              variant="outline"
              className="gap-2 border-green-600 text-green-600 hover:bg-green-50"
            >
              <FileSpreadsheet className="w-4 h-4" />
              CSV
            </Button>

            <Button 
              onClick={() => handleGeneratePDF('all')}
              disabled={isGeneratingPDF}
              variant="outline"
              className="gap-2"
            >
              <FileDown className="w-4 h-4" />
              {isGeneratingPDF ? 'Gerando...' : 'PDF Completo'}
            </Button>

            <Button 
              onClick={() => handleGenerateNotesReport('receita')}
              variant="outline"
              className="gap-2 border-green-200 text-green-700 hover:bg-green-50"
            >
              <FileText className="w-4 h-4" />
              TXT Receitas
            </Button>

            <Button 
              onClick={() => handleGenerateNotesReport('despesa')}
              variant="outline"
              className="gap-2 border-red-200 text-red-700 hover:bg-red-50"
            >
              <FileText className="w-4 h-4" />
              TXT Despesas
            </Button>
          </div>
        </motion.div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-6">
          <BalanceLineChart 
            data={monthlyData} 
            title="Evolução do Saldo" 
          />
          <ExpenseBarChart 
            data={monthlyData} 
            title="Receitas x Despesas por Mês" 
          />
        </div>

        {/* Summary */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>
              Resumo de {useCustomRange 
                ? `${format(new Date(dateRange.startDate), 'dd/MM/yyyy')} - ${format(new Date(dateRange.endDate), 'dd/MM/yyyy')}`
                : `${monthName} ${selectedYear}`
              }
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-green-50 rounded-xl">
                <p className="text-xs sm:text-sm text-green-600">Total Receitas</p>
                <p className="text-xl sm:text-2xl font-bold text-green-700">{formatCurrency(totalIncome)}</p>
              </div>
              <div className="p-4 bg-red-50 rounded-xl">
                <p className="text-xs sm:text-sm text-red-600">Total Despesas</p>
                <p className="text-xl sm:text-2xl font-bold text-red-700">{formatCurrency(totalExpense)}</p>
              </div>
              <div className={`p-4 rounded-xl ${totalIncome - totalExpense >= 0 ? 'bg-blue-50' : 'bg-red-50'}`}>
                <p className={`text-xs sm:text-sm ${totalIncome - totalExpense >= 0 ? 'text-blue-600' : 'text-red-600'}`}>Saldo</p>
                <p className={`text-xl sm:text-2xl font-bold ${totalIncome - totalExpense >= 0 ? 'text-blue-700' : 'text-red-700'}`}>
                  {formatCurrency(totalIncome - totalExpense)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pie Chart */}
          <CategoryPieChart data={categoryChartData} title="Despesas por Categoria" />

          {/* Expenses by Category Table */}
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg">Detalhamento de Despesas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">Categoria</TableHead>
                      <TableHead className="text-center min-w-[60px]">Qtd</TableHead>
                      <TableHead className="text-right min-w-[120px]">Total</TableHead>
                      <TableHead className="text-right min-w-[60px]">%</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(expensesByCategory)
                      .sort(([,a], [,b]) => b.total - a.total)
                      .map(([name, data]) => {
                        const percentage = totalExpense > 0 ? (data.total / totalExpense * 100).toFixed(1) : 0;
                        const cat = categories.find(c => c.name === name);
                        return (
                          <TableRow key={name}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <div 
                                  className="w-3 h-3 rounded-full flex-shrink-0"
                                  style={{ backgroundColor: cat?.color || '#6b7280' }}
                                />
                                <span className="truncate">{name}</span>
                              </div>
                            </TableCell>
                            <TableCell className="text-center">{data.count}</TableCell>
                            <TableCell className="text-right font-medium whitespace-nowrap">
                              {formatCurrency(data.total)}
                            </TableCell>
                            <TableCell className="text-right text-gray-500">
                              {percentage}%
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Income by Category */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Detalhamento de Receitas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">Categoria</TableHead>
                    <TableHead className="text-center min-w-[80px]">Quantidade</TableHead>
                    <TableHead className="text-right min-w-[120px]">Total</TableHead>
                    <TableHead className="text-right min-w-[60px]">%</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(incomeByCategory)
                    .sort(([,a], [,b]) => b.total - a.total)
                    .map(([name, data]) => {
                      const percentage = totalIncome > 0 ? (data.total / totalIncome * 100).toFixed(1) : 0;
                      const cat = categories.find(c => c.name === name);
                      return (
                        <TableRow key={name}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-3 h-3 rounded-full flex-shrink-0"
                                style={{ backgroundColor: cat?.color || '#22c55e' }}
                              />
                              <span className="truncate">{name}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">{data.count}</TableCell>
                          <TableCell className="text-right font-medium text-green-600 whitespace-nowrap">
                            {formatCurrency(data.total)}
                          </TableCell>
                          <TableCell className="text-right text-gray-500">
                            {percentage}%
                          </TableCell>
                        </TableRow>
                      );
                    })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}