import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Plus, CreditCard as CreditCardIcon, Calendar, DollarSign } from "lucide-react";
import { motion } from "framer-motion";
import CreditCardForm from "@/components/creditcards/CreditCardForm";
import CreditCardExpenseForm from "@/components/creditcards/CreditCardExpenseForm";
import CreditCardList from "@/components/creditcards/CreditCardList";
import CreditCardExpensesList from "@/components/creditcards/CreditCardExpensesList";

export default function CreditCards() {
  const [showCardForm, setShowCardForm] = useState(false);
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [selectedCard, setSelectedCard] = useState(null);
  const [editingExpense, setEditingExpense] = useState(null);

  const queryClient = useQueryClient();

  const { data: cards = [] } = useQuery({
    queryKey: ['credit-cards'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.CreditCard.filter({ created_by: user.email }, '-created_date');
    },
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['credit-card-expenses'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.CreditCardExpense.filter({ created_by: user.email }, '-month');
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const activeCards = cards.filter(c => c.is_active);
  const totalLimit = activeCards.reduce((sum, c) => sum + (c.limit || 0), 0);
  
  const getCurrentMonth = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };
  
  const currentMonth = getCurrentMonth();
  const currentMonthExpenses = expenses.filter(e => e.month === currentMonth);
  const totalCurrentMonth = currentMonthExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const unpaidCurrentMonth = currentMonthExpenses.filter(e => !e.is_paid).reduce((sum, e) => sum + (e.amount || 0), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 rounded-xl">
                <CreditCardIcon className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Cartões de Crédito</h1>
                <p className="text-gray-500">Gerencie seus cartões e faturas</p>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={() => {
                setSelectedCard(null);
                setShowExpenseForm(true);
              }}
              variant="outline"
              className="gap-2"
              disabled={cards.length === 0}
            >
              <DollarSign className="w-4 h-4" />
              Lançar Fatura
            </Button>
            <Button 
              onClick={() => setShowCardForm(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Cartão
            </Button>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <CreditCardIcon className="w-8 h-8" />
                <div>
                  <p className="text-blue-100 text-sm">Cartões Ativos</p>
                  <p className="text-2xl font-bold">{activeCards.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Limite Total</p>
              <p className="text-2xl font-bold text-blue-900">{formatCurrency(totalLimit)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Fatura do Mês</p>
              <p className="text-2xl font-bold text-orange-600">{formatCurrency(totalCurrentMonth)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">A Pagar</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(unpaidCurrentMonth)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Cards List */}
        <CreditCardList
          cards={cards}
          expenses={expenses}
          onEdit={(card) => {
            setEditingCard(card);
            setShowCardForm(true);
          }}
          onAddExpense={(card) => {
            setSelectedCard(card);
            setShowExpenseForm(true);
          }}
        />

        {/* Expenses List */}
        <CreditCardExpensesList
          expenses={expenses}
          cards={cards}
          onEdit={(expense) => {
            setEditingExpense(expense);
            setShowExpenseForm(true);
          }}
        />

        {/* Forms */}
        <CreditCardForm
          isOpen={showCardForm}
          onClose={() => {
            setShowCardForm(false);
            setEditingCard(null);
          }}
          card={editingCard}
        />

        <CreditCardExpenseForm
          isOpen={showExpenseForm}
          onClose={() => {
            setShowExpenseForm(false);
            setSelectedCard(null);
            setEditingExpense(null);
          }}
          cards={cards}
          selectedCard={selectedCard}
          expense={editingExpense}
        />
      </div>
    </div>
  );
}