import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Plus, ShoppingCart, Trash2, FileText, Send, X, Save, Pencil, Settings, Check, ChevronsUpDown } from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const DEFAULT_STORES = [
  "MERCADO ZONA SUL IPANAMA",
  "MERCADO RIO SUL DE XERÉM",
  "MERCADO MODESTO",
  "MERCADO ANTUNES",
  "MERCADO TROPICAL DE XERÉM",
  "PADARIA DO BETÃO",
  "PADARIA BELLA MASSA",
  "PADARIA DIVINO PÃO",
  "PIZZARIA DOIS IRMÃOS",
  "MERCADO FONTOURA",
  "MERCADO CARIOCA",
  "BAR E RESTAURANTE BERENICE",
  "AVIÁRIO DO NENÉM",
  "FRANGO DA WILSON DE ARAÚJO",
  "MERCADO MULTI MARKET",
  "PRACA DE ALIMENTAÇÃO CAXIAS SHOPPING",
  "PRACA DE ALIMENTAÇÃO NORTE SHOPPING"
];

const MONTHS = [
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

export default function GroceryExpenses() {
  const [showForm, setShowForm] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [showWhatsAppDialog, setShowWhatsAppDialog] = useState(false);
  const [showManageStores, setShowManageStores] = useState(false);
  const [newStoreName, setNewStoreName] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth().toString());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [selectedStore, setSelectedStore] = useState("");
  const [showCustomStore, setShowCustomStore] = useState(false);
  const [openStoreCombobox, setOpenStoreCombobox] = useState(false);
  const [storeSearchValue, setStoreSearchValue] = useState("");
  const [formData, setFormData] = useState({
    store_name: "",
    amount: "",
    date: new Date().toISOString().split('T')[0],
    notes: ""
  });

  const queryClient = useQueryClient();
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  const { data: expenses = [] } = useQuery({
    queryKey: ['grocery-expenses'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.GroceryExpense.filter({ created_by: user.email }, '-date');
    },
  });

  const { data: customStores = [] } = useQuery({
    queryKey: ['custom-stores'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Store.filter({ created_by: user.email }, 'name');
    },
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.GroceryExpense.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grocery-expenses'] });
      handleCloseForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.GroceryExpense.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grocery-expenses'] });
      handleCloseForm();
    },
  });

  const addStoreMutation = useMutation({
    mutationFn: (name) => base44.entities.Store.create({ name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-stores'] });
      setNewStoreName("");
    },
  });

  const deleteStoreMutation = useMutation({
    mutationFn: (id) => base44.entities.Store.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custom-stores'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.GroceryExpense.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grocery-expenses'] });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      amount: parseFloat(formData.amount)
    };
    
    if (editingExpense) {
      updateMutation.mutate({ id: editingExpense.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingExpense(null);
    setSelectedStore("");
    setShowCustomStore(false);
    setStoreSearchValue("");
    setFormData({
      store_name: "",
      amount: "",
      date: new Date().toISOString().split('T')[0],
      notes: ""
    });
  };

  const handleEdit = (expense) => {
    setEditingExpense(expense);
    const allStores = [...DEFAULT_STORES, ...customStores.map(s => s.name)];
    const isPreset = allStores.includes(expense.store_name);
    if (isPreset) {
      setSelectedStore(expense.store_name);
      setShowCustomStore(false);
    } else {
      setSelectedStore("OUTRO");
      setShowCustomStore(true);
    }
    setFormData({
      store_name: expense.store_name,
      amount: expense.amount.toString(),
      date: expense.date,
      notes: expense.notes || ""
    });
    setShowForm(true);
  };

  const handleStoreChange = (value) => {
    setSelectedStore(value);
    setStoreSearchValue(value);
    if (value === "OUTRO") {
      setShowCustomStore(true);
      setFormData({ ...formData, store_name: "" });
    } else {
      setShowCustomStore(false);
      setFormData({ ...formData, store_name: value });
    }
    setOpenStoreCombobox(false);
  };

  const handleAddStore = (e) => {
    e.preventDefault();
    if (newStoreName.trim()) {
      addStoreMutation.mutate(newStoreName.trim().toUpperCase());
    }
  };

  const handleDeleteStore = (id) => {
    if (window.confirm('Deseja remover este estabelecimento da lista?')) {
      deleteStoreMutation.mutate(id);
    }
  };

  const allStores = [...DEFAULT_STORES, ...customStores.map(s => s.name), "OUTRO"];

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este gasto?')) {
      deleteMutation.mutate(id);
    }
  };

  // Filter by selected month
  const filteredExpenses = expenses.filter(e => {
    const date = new Date(e.date);
    return date.getMonth().toString() === selectedMonth && 
           date.getFullYear().toString() === selectedYear;
  });

  const monthlyTotal = filteredExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);

  const generateReport = () => {
    const monthName = MONTHS.find(m => m.value === selectedMonth)?.label;
    let content = `===========================================\n`;
    content += `RELATÓRIO DE GASTOS COM MERCADO\n`;
    content += `${monthName} ${selectedYear}\n`;
    content += `===========================================\n\n`;
    
    if (filteredExpenses.length === 0) {
      content += `Nenhum gasto registrado neste período.\n`;
    } else {
      filteredExpenses.forEach((expense, index) => {
        content += `${index + 1}. ${expense.store_name}\n`;
        const [year, month, day] = expense.date.split('-');
        const dateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
        content += `   Data: ${format(dateObj, 'dd/MM/yyyy', { locale: ptBR })}\n`;
        content += `   Valor: ${formatCurrency(expense.amount)}\n`;
        if (expense.notes) {
          content += `   Observações: ${expense.notes}\n`;
        }
        content += `\n-------------------------------------------\n\n`;
      });
      
      content += `\nTOTAL DO MÊS: ${formatCurrency(monthlyTotal)}\n`;
      content += `Total de compras: ${filteredExpenses.length}\n`;
      content += `Média por compra: ${formatCurrency(monthlyTotal / filteredExpenses.length)}\n`;
    }
    
    return content;
  };

  const handleDownloadReport = () => {
    const content = generateReport();
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const monthName = MONTHS.find(m => m.value === selectedMonth)?.label;
    a.download = `gastos-mercado-${monthName}-${selectedYear}.txt`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const handleSendWhatsApp = () => {
    if (!whatsappNumber) {
      alert('Por favor, digite o número do WhatsApp');
      return;
    }
    
    const content = generateReport();
    const encodedMessage = encodeURIComponent(content);
    const cleanNumber = whatsappNumber.replace(/\D/g, '');
    const url = `https://wa.me/${cleanNumber}?text=${encodedMessage}`;
    window.open(url, '_blank');
    setShowWhatsAppDialog(false);
    setWhatsappNumber("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-xl">
                <ShoppingCart className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Gastos com Mercado</h1>
                <p className="text-gray-500">Controle seus gastos com compras</p>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={() => setShowManageStores(true)}
              variant="outline"
              className="gap-2"
            >
              <Settings className="w-4 h-4" />
              Gerenciar Locais
            </Button>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Gasto
            </Button>
          </div>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-36 bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MONTHS.map(month => (
                <SelectItem key={month.value} value={month.value}>
                  {month.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedYear} onValueChange={setSelectedYear}>
            <SelectTrigger className="w-24 bg-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {years.map(year => (
                <SelectItem key={year} value={year}>{year}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button 
            onClick={handleDownloadReport}
            variant="outline"
            className="gap-2"
          >
            <FileText className="w-4 h-4" />
            Baixar Relatório
          </Button>

          <Button 
            onClick={() => setShowWhatsAppDialog(true)}
            variant="outline"
            className="gap-2 border-green-600 text-green-600 hover:bg-green-50"
          >
            <Send className="w-4 h-4" />
            Enviar WhatsApp
          </Button>
        </div>

        {/* Summary Card */}
        <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">Total Gasto no Mês</p>
                <p className="text-3xl font-bold">{formatCurrency(monthlyTotal)}</p>
                <p className="text-green-100 text-sm mt-2">{filteredExpenses.length} compras</p>
              </div>
              <ShoppingCart className="w-16 h-16 opacity-30" />
            </div>
          </CardContent>
        </Card>

        {/* Expenses Table */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Gastos de {MONTHS.find(m => m.value === selectedMonth)?.label} {selectedYear}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">Mercado</TableHead>
                    <TableHead className="min-w-[100px]">Data</TableHead>
                    <TableHead className="text-right min-w-[120px]">Valor</TableHead>
                    <TableHead className="min-w-[200px]">Observações</TableHead>
                    <TableHead className="text-center min-w-[80px]">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.map((expense) => {
                    const [year, month, day] = expense.date.split('-');
                    const dateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
                    return (
                      <TableRow key={expense.id}>
                        <TableCell className="font-medium">{expense.store_name}</TableCell>
                        <TableCell>{format(dateObj, 'dd/MM/yyyy')}</TableCell>
                      <TableCell className="text-right font-bold text-green-600">
                        {formatCurrency(expense.amount)}
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{expense.notes || '-'}</TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(expense)}
                            className="h-8 w-8 text-blue-600 hover:bg-blue-50"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(expense.id)}
                            className="h-8 w-8 text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
            {filteredExpenses.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum gasto registrado neste mês</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Form Dialog */}
        <Dialog open={showForm} onOpenChange={handleCloseForm}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingExpense ? 'Editar Gasto' : 'Novo Gasto com Mercado'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Nome do Mercado *</Label>
                <Popover open={openStoreCombobox} onOpenChange={setOpenStoreCombobox}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={openStoreCombobox}
                      className="w-full justify-between"
                    >
                      {selectedStore || "Selecione o mercado..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[400px] p-0">
                    <Command>
                      <CommandInput 
                        placeholder="Pesquisar mercado..." 
                        value={storeSearchValue}
                        onValueChange={setStoreSearchValue}
                      />
                      <CommandList>
                        <CommandEmpty>
                          <div className="p-2">
                            <p className="text-sm text-gray-500 mb-2">Nenhum resultado encontrado</p>
                            <Button
                              size="sm"
                              className="w-full"
                              onClick={() => {
                                if (storeSearchValue.trim()) {
                                  handleStoreChange("OUTRO");
                                  setFormData({ ...formData, store_name: storeSearchValue.trim().toUpperCase() });
                                }
                              }}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Adicionar "{storeSearchValue}"
                            </Button>
                          </div>
                        </CommandEmpty>
                        <CommandGroup>
                          {allStores
                            .filter(store => 
                              store.toLowerCase().includes(storeSearchValue.toLowerCase())
                            )
                            .map((store) => (
                              <CommandItem
                                key={store}
                                value={store}
                                onSelect={() => handleStoreChange(store)}
                              >
                                <Check
                                  className={`mr-2 h-4 w-4 ${
                                    selectedStore === store ? "opacity-100" : "opacity-0"
                                  }`}
                                />
                                {store}
                              </CommandItem>
                            ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              {showCustomStore && (
                <div className="space-y-2">
                  <Label>Digite o nome do mercado *</Label>
                  <Input
                    value={formData.store_name}
                    onChange={(e) => setFormData({ ...formData, store_name: e.target.value })}
                    placeholder="Ex: Supermercado ABC"
                    required
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Valor (R$) *</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="0,00"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Data *</Label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Observações</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Observações sobre a compra..."
                  rows={3}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={handleCloseForm} className="flex-1">
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
                <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700">
                  <Save className="w-4 h-4 mr-2" />
                  Salvar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* WhatsApp Dialog */}
        <Dialog open={showWhatsAppDialog} onOpenChange={setShowWhatsAppDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Enviar Relatório por WhatsApp</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Número do WhatsApp *</Label>
                <Input
                  type="tel"
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  placeholder="Ex: 5511999999999"
                />
                <p className="text-xs text-gray-500">Digite com código do país e DDD (ex: 5511999999999)</p>
              </div>

              <div className="flex gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowWhatsAppDialog(false);
                    setWhatsappNumber("");
                  }} 
                  className="flex-1"
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleSendWhatsApp}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Manage Stores Dialog */}
        <Dialog open={showManageStores} onOpenChange={setShowManageStores}>
          <DialogContent className="max-w-md max-h-[600px] flex flex-col">
            <DialogHeader>
              <DialogTitle>Gerenciar Locais</DialogTitle>
            </DialogHeader>
            
            <div className="flex-1 overflow-y-auto space-y-4">
              {/* Add Store Form */}
              <form onSubmit={handleAddStore} className="space-y-2">
                <Label>Adicionar Novo Local</Label>
                <div className="flex gap-2">
                  <Input
                    value={newStoreName}
                    onChange={(e) => setNewStoreName(e.target.value)}
                    placeholder="Nome do estabelecimento"
                    className="flex-1"
                  />
                  <Button type="submit" size="icon" className="bg-green-600 hover:bg-green-700">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </form>

              {/* Default Stores */}
              <div>
                <Label className="text-sm text-gray-600 mb-2 block">Locais Padrão</Label>
                <div className="space-y-1">
                  {DEFAULT_STORES.map((store) => (
                    <div key={store} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                      <span className="text-sm">{store}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Custom Stores */}
              {customStores.length > 0 && (
                <div>
                  <Label className="text-sm text-gray-600 mb-2 block">Meus Locais</Label>
                  <div className="space-y-1">
                    {customStores.map((store) => (
                      <div key={store.id} className="flex items-center justify-between p-2 bg-blue-50 rounded-lg">
                        <span className="text-sm">{store.name}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteStore(store.id)}
                          className="h-8 w-8 text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t">
              <Button 
                onClick={() => setShowManageStores(false)} 
                className="w-full"
              >
                Fechar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}