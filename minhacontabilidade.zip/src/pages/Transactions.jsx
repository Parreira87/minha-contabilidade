import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Plus, Search, Filter } from "lucide-react";
import TransactionForm from "@/components/transactions/TransactionForm";
import TransactionList from "@/components/transactions/TransactionList";
import QuickStats from "@/components/dashboard/QuickStats";
import { motion } from "framer-motion";

const MONTHS = [
  { value: "all", label: "Todos os Meses" },
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

export default function Transactions() {
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [filterMonth, setFilterMonth] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const queryClient = useQueryClient();

  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const user = await base44.auth.me();
      const txs = await base44.entities.Transaction.filter({ created_by: user.email }, '-created_date');
      const cats = await base44.entities.Category.filter({ created_by: user.email });
      return txs.map(t => ({
        ...t,
        category_icon: cats.find(c => c.id === t.category_id)?.icon
      }));
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: user.email });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Transaction.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
    },
  });

  const handleEdit = (transaction) => {
    setEditingTransaction(transaction);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este lançamento?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleTogglePaid = async (transaction) => {
    const updateData = {
      is_paid: !transaction.is_paid
    };
    
    // If marking as paid, set payment_date to today
    if (!transaction.is_paid) {
      updateData.payment_date = new Date().toISOString().split('T')[0];
    } else {
      // If unmarking, clear payment_date
      updateData.payment_date = null;
    }
    
    await base44.entities.Transaction.update(transaction.id, updateData);
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
  };

  const handleRepeatToNextMonth = async (transaction) => {
    // Calculate next month dates
    const currentDate = new Date(transaction.date);
    const currentDueDate = new Date(transaction.due_date);
    
    const nextMonthDate = new Date(currentDate);
    nextMonthDate.setMonth(nextMonthDate.getMonth() + 1);
    
    const nextMonthDueDate = new Date(currentDueDate);
    nextMonthDueDate.setMonth(nextMonthDueDate.getMonth() + 1);
    
    // Create new transaction for next month
    const newTransaction = {
      type: transaction.type,
      date: nextMonthDate.toISOString().split('T')[0],
      due_date: nextMonthDueDate.toISOString().split('T')[0],
      description: transaction.description,
      category_id: transaction.category_id,
      category_name: transaction.category_name,
      category_icon: transaction.category_icon,
      amount: transaction.amount,
      payment_method: transaction.payment_method,
      notes: transaction.notes,
      is_paid: false,
      installment_number: transaction.installment_number,
      total_installments: transaction.total_installments
    };
    
    await base44.entities.Transaction.create(newTransaction);
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingTransaction(null);
  };

  const handleSave = () => {
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
  };

  // Filter transactions
  const filteredTransactions = transactions.filter(t => {
    const matchesType = filterType === "all" || t.type === filterType;
    const matchesSearch = t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         t.category_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesMonth = true;
    if (filterMonth !== "all") {
      const date = new Date(t.date);
      matchesMonth = date.getMonth().toString() === filterMonth;
    }

    return matchesType && matchesSearch && matchesMonth;
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Calculate totals - PENDING only
  const totalIncome = filteredTransactions
    .filter(t => t.type === 'receita' && !t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === 'despesa' && !t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Lançamentos</h1>
              <p className="text-gray-500">Gerencie suas receitas e despesas</p>
            </div>
          </div>

          <Button 
            onClick={() => setShowForm(true)}
            className="bg-blue-900 hover:bg-blue-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Lançamento
          </Button>
        </motion.div>

        {/* Quick Stats */}
        <QuickStats transactions={filteredTransactions} />

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Buscar por descrição ou categoria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white"
            />
          </div>

          <div className="flex gap-3">
            <Tabs value={filterType} onValueChange={setFilterType}>
              <TabsList className="bg-white">
                <TabsTrigger value="all">Todos</TabsTrigger>
                <TabsTrigger value="receita" className="data-[state=active]:bg-green-100 data-[state=active]:text-green-700">
                  Receitas
                </TabsTrigger>
                <TabsTrigger value="despesa" className="data-[state=active]:bg-red-100 data-[state=active]:text-red-700">
                  Despesas
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <Select value={filterMonth} onValueChange={setFilterMonth}>
              <SelectTrigger className="w-40 bg-white">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MONTHS.map(month => (
                  <SelectItem key={month.value} value={month.value}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <p className="text-sm text-gray-500">A Receber</p>
            <p className="text-lg font-bold text-green-600">{formatCurrency(totalIncome)}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <p className="text-sm text-gray-500">A Pagar</p>
            <p className="text-lg font-bold text-red-600">{formatCurrency(totalExpense)}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <p className="text-sm text-gray-500">Saldo Pendente</p>
            <p className={`text-lg font-bold ${totalIncome - totalExpense >= 0 ? 'text-blue-900' : 'text-red-600'}`}>
              {formatCurrency(totalIncome - totalExpense)}
            </p>
          </div>
        </div>

        {/* Transaction List */}
        <TransactionList
          transactions={filteredTransactions}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onTogglePaid={handleTogglePaid}
          onRepeat={handleRepeatToNextMonth}
        />

        {/* Transaction Form Modal */}
        <TransactionForm
          isOpen={showForm}
          onClose={handleCloseForm}
          onSave={handleSave}
          transaction={editingTransaction}
          categories={categories}
        />
      </div>
    </div>
  );
}