import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Plus, Pencil, Trash2, Tag, X, Save } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const COLORS = [
  "#3b82f6", "#22c55e", "#ef4444", "#f59e0b", "#8b5cf6",
  "#ec4899", "#06b6d4", "#84cc16", "#f97316", "#14b8a6",
  "#6366f1", "#a855f7", "#f472b6", "#0ea5e9", "#dc2626"
];

const ICONS = [
  "🏠", "🍔", "🚗", "⚡", "💊", "🎓", "🛒", "🎮", "✈️", "🎬",
  "📱", "💰", "🎯", "🔧", "👕", "🍕", "🏥", "⛽", "📚", "💻",
  "🎵", "🏋️", "☕", "🚌", "🎨", "🏪", "🍎", "💳", "📺", "🎁",
  "🍽️", "🏖️", "🚕", "🏦", "💼", "🎸", "🌮", "🍺", "🎂", "🍩",
  "🐕", "🐱", "🌺", "🎪", "🏠", "🔑", "🛏️", "🧴", "💄", "👟",
  "⚽", "🏃", "🧘", "🎾", "🏊", "🚴", "🥗", "🥤", "🍜", "🍱",
  "📖", "✏️", "📝", "🖊️", "🖍️", "📐", "📏", "🎒", "🧳", "👔",
  "👗", "👠", "👜", "⌚", "💍", "🕶️", "🧢", "🎩", "👑", "🌟",
  "🔌", "💡", "🔦", "🕯️", "🧯", "🧲", "🔭", "🔬", "💉", "🩺",
  "🛁", "🚿", "🧼", "🧽", "🧹", "🧺", "🗑️", "🛒", "🏪", "🏬"
];

export default function Categories() {
  const [showForm, setShowForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [formData, setFormData] = useState({
    name: "",
    type: "despesa",
    color: COLORS[0],
    icon: ICONS[0]
  });

  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: user.email });
    },
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Category.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      handleCloseForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Category.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      handleCloseForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Category.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
    },
  });

  const handleEdit = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      type: category.type,
      color: category.color || COLORS[0],
      icon: category.icon || ICONS[0]
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta categoria?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingCategory(null);
    setFormData({ name: "", type: "despesa", color: COLORS[0], icon: ICONS[0] });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCategory) {
      updateMutation.mutate({ id: editingCategory.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const filteredCategories = categories.filter(c => 
    filterType === "all" || c.type === filterType
  );

  const expenseCategories = filteredCategories.filter(c => c.type === 'despesa');
  const incomeCategories = filteredCategories.filter(c => c.type === 'receita');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-xl">
                <Tag className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Categorias</h1>
                <p className="text-gray-500">Organize seus lançamentos</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={() => setShowForm(true)}
            className="bg-blue-900 hover:bg-blue-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Categoria
          </Button>
        </motion.div>

        {/* Filter */}
        <Tabs value={filterType} onValueChange={setFilterType}>
          <TabsList className="bg-white">
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="receita" className="data-[state=active]:bg-green-100 data-[state=active]:text-green-700">
              Receitas
            </TabsTrigger>
            <TabsTrigger value="despesa" className="data-[state=active]:bg-red-100 data-[state=active]:text-red-700">
              Despesas
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Categories Grid */}
        {filterType !== "receita" && expenseCategories.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-800 mb-3">Categorias de Despesas</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <AnimatePresence>
                {expenseCategories.map((category, index) => (
                  <motion.div
                    key={category.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ delay: index * 0.03 }}
                  >
                    <Card className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {category.icon && <span className="text-xl">{category.icon}</span>}
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: category.color }}
                          />
                          <span className="font-medium text-gray-800">{category.name}</span>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(category)}
                            className="h-8 w-8 text-gray-400 hover:text-blue-600"
                          >
                            <Pencil className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(category.id)}
                            className="h-8 w-8 text-gray-400 hover:text-red-600"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {filterType !== "despesa" && incomeCategories.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-800 mb-3">Categorias de Receitas</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <AnimatePresence>
                {incomeCategories.map((category, index) => (
                  <motion.div
                    key={category.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ delay: index * 0.03 }}
                  >
                    <Card className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {category.icon && <span className="text-xl">{category.icon}</span>}
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: category.color }}
                          />
                          <span className="font-medium text-gray-800">{category.name}</span>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(category)}
                            className="h-8 w-8 text-gray-400 hover:text-blue-600"
                          >
                            <Pencil className="w-3 h-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(category.id)}
                            className="h-8 w-8 text-gray-400 hover:text-red-600"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Form Dialog */}
        <Dialog open={showForm} onOpenChange={handleCloseForm}>
          <DialogContent className="max-w-lg max-h-[90vh] p-0 gap-0 flex flex-col">
            <DialogHeader className="p-6 pb-4 flex-shrink-0">
              <DialogTitle>
                {editingCategory ? "Editar Categoria" : "Nova Categoria"}
              </DialogTitle>
            </DialogHeader>

            <form id="category-form" onSubmit={handleSubmit} className="px-6 pb-4 space-y-4 overflow-y-auto flex-1">
              <div className="space-y-2">
                <Label>Nome</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Nome da categoria"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Tipo</Label>
                <Select 
                  value={formData.type} 
                  onValueChange={(v) => setFormData({ ...formData, type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="despesa">Despesa</SelectItem>
                    <SelectItem value="receita">Receita</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Ícone</Label>
                <div className="grid grid-cols-12 gap-1.5 max-h-40 overflow-y-auto p-2 border rounded-lg bg-gray-50">
                  {ICONS.map(icon => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setFormData({ ...formData, icon })}
                      className={`w-9 h-9 text-lg flex items-center justify-center rounded-lg transition-all ${
                        formData.icon === icon ? 'bg-blue-500 text-white scale-105 shadow-md' : 'bg-white hover:bg-blue-50 hover:scale-105'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Cor</Label>
                <div className="grid grid-cols-8 gap-2">
                  {COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData({ ...formData, color })}
                      className={`w-10 h-10 rounded-lg transition-all ${
                        formData.color === color ? 'ring-2 ring-offset-2 ring-blue-500 scale-105 shadow-md' : 'hover:scale-105'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </form>

            <div className="flex gap-3 px-6 py-4 border-t bg-gray-50 flex-shrink-0">
              <Button type="button" variant="outline" onClick={handleCloseForm} className="flex-1">
                <X className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
              <Button type="submit" form="category-form" className="flex-1 bg-blue-900 hover:bg-blue-800">
                <Save className="w-4 h-4 mr-2" />
                Salvar
              </Button>
            </div>
            </DialogContent>
            </Dialog>
      </div>
    </div>
  );
}