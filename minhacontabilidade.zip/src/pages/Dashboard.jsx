import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  CalendarDays, 
  Plus,
  PiggyBank
} from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import MonthlyChart from "@/components/dashboard/MonthlyChart";
import CategoryPieChart from "@/components/dashboard/CategoryPieChart";
import BarChartComparison from "@/components/dashboard/BarChartComparison";
import TransactionForm from "@/components/transactions/TransactionForm";
import UpcomingDueDates from "@/components/dashboard/UpcomingDueDates";
import TopExpenses from "@/components/dashboard/TopExpenses";

import { motion } from "framer-motion";

const MONTHS = [
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

export default function Dashboard() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth().toString());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [showTransactionForm, setShowTransactionForm] = useState(false);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: transactions = [], isLoading, refetch } = useQuery({
    queryKey: ['transactions', selectedMonth, selectedYear],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Transaction.filter({ created_by: currentUser.email }, '-due_date');
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: currentUser.email });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filter transactions for selected month
  const filteredTransactions = transactions.filter(t => {
    const date = new Date(t.date);
    return date.getMonth().toString() === selectedMonth && 
           date.getFullYear().toString() === selectedYear;
  });

  // Calculate totals - PENDING (not paid/received yet)
  const totalIncomePending = filteredTransactions
    .filter(t => t.type === 'receita' && !t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalExpensePending = filteredTransactions
    .filter(t => t.type === 'despesa' && !t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  // Calculate REALIZED balance (already paid/received)
  const totalIncomeRealized = filteredTransactions
    .filter(t => t.type === 'receita' && t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const totalExpenseRealized = filteredTransactions
    .filter(t => t.type === 'despesa' && t.is_paid)
    .reduce((sum, t) => sum + (t.amount || 0), 0);

  const currentBalance = totalIncomeRealized - totalExpenseRealized;

  // Predicted balance (realized + pending)
  const predictedBalance = (totalIncomeRealized + totalIncomePending) - (totalExpenseRealized + totalExpensePending);

  // Generate daily data for charts
  const generateDailyData = () => {
    const monthStart = startOfMonth(new Date(parseInt(selectedYear), parseInt(selectedMonth)));
    const monthEnd = endOfMonth(monthStart);
    const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

    let cumulative = 0;
    return days.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');
      const dayTransactions = filteredTransactions.filter(t => t.date === dayStr);
      
      const income = dayTransactions
        .filter(t => t.type === 'receita')
        .reduce((sum, t) => sum + (t.amount || 0), 0);
      
      const expense = dayTransactions
        .filter(t => t.type === 'despesa')
        .reduce((sum, t) => sum + (t.amount || 0), 0);

      cumulative += income - expense;

      return {
        day: format(day, 'dd'),
        income,
        expense,
        balance: cumulative
      };
    });
  };

  // Generate category data for pie chart
  const generateCategoryData = () => {
    const expensesByCategory = {};
    filteredTransactions
      .filter(t => t.type === 'despesa')
      .forEach(t => {
        const catName = t.category_name || 'Outros';
        expensesByCategory[catName] = (expensesByCategory[catName] || 0) + (t.amount || 0);
      });

    const category = categories.find(c => c.name === Object.keys(expensesByCategory)[0]);
    
    return Object.entries(expensesByCategory)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 8)
      .map(([name, value]) => {
        const cat = categories.find(c => c.name === name);
        return {
          name,
          value,
          color: cat?.color
        };
      });
  };

  const dailyData = generateDailyData();
  const categoryData = generateCategoryData();

  const handlePayTransaction = async (transaction) => {
    await base44.entities.Transaction.update(transaction.id, { is_paid: true });
    refetch();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6844a67bb310be18a8ed5e4d/5445de869_ChatGPTImage30dedezde202519_59_17.png"
              alt="Logo"
              className="w-16 h-16 object-contain"
            />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Minha Contabilidade</h1>
              <p className="text-gray-500">Controle financeiro pessoal</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-36 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MONTHS.map(month => (
                  <SelectItem key={month.value} value={month.value}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-24 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button 
              onClick={() => setShowTransactionForm(true)}
              className="bg-blue-900 hover:bg-blue-800"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Lançamento
            </Button>
          </div>
        </motion.div>

        {/* Upcoming Due Dates Alert */}
        <UpcomingDueDates transactions={transactions} onPayTransaction={handlePayTransaction} />

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Saldo Atual"
            value={formatCurrency(currentBalance)}
            icon={Wallet}
            color={currentBalance >= 0 ? "bg-blue-500" : "bg-red-500"}
          />
          <StatCard
            title="A Receber"
            value={formatCurrency(totalIncomePending)}
            icon={TrendingUp}
            color="bg-green-500"
          />
          <StatCard
            title="A Pagar"
            value={formatCurrency(totalExpensePending)}
            icon={TrendingDown}
            color="bg-red-500"
          />
          <StatCard
            title="Saldo Previsto"
            value={formatCurrency(predictedBalance)}
            icon={Target}
            color="bg-purple-500"
          />
        </div>

        {/* Quick Access */}
        <Link to={createPageUrl("Transactions")}>
          <Card className="p-6 border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer bg-gradient-to-r from-green-600 to-emerald-500 text-white">
            <div className="flex items-center gap-4">
              <div className="p-4 bg-white/20 rounded-xl">
                <PiggyBank className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Lançamentos</h3>
                <p className="text-green-100">Gerencie suas receitas e despesas</p>
              </div>
            </div>
          </Card>
        </Link>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <MonthlyChart 
            data={dailyData} 
            title="Evolução do Saldo no Mês" 
          />
          <CategoryPieChart 
            data={categoryData} 
            title="Despesas por Categoria" 
          />
        </div>

        <BarChartComparison 
          data={dailyData} 
          title="Receitas x Despesas por Dia" 
        />

        {/* Top Expenses */}
        <TopExpenses transactions={filteredTransactions} categories={categories} />

        {/* Transaction Form Modal */}
        <TransactionForm
          isOpen={showTransactionForm}
          onClose={() => setShowTransactionForm(false)}
          onSave={refetch}
          categories={categories}
        />
      </div>
    </div>
  );
}