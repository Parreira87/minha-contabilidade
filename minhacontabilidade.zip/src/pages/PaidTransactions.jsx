import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ArrowLeft, FileDown, Search, CheckCircle, Calendar } from "lucide-react";
import { motion } from "framer-motion";

const MONTHS = [
  { value: "all", label: "Todos os Meses" },
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

const PAYMENT_METHODS = {
  dinheiro: "Dinheiro",
  pix: "PIX",
  cartao_credito: "Cartão de Crédito",
  cartao_debito: "Cartão de Débito",
  transferencia: "Transferência",
  boleto: "Boleto"
};

export default function PaidTransactions() {
  const [selectedMonth, setSelectedMonth] = useState("all");
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("all");

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Transaction.filter({ created_by: user.email }, '-date');
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: user.email });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filter only paid transactions
  const paidTransactions = transactions.filter(t => {
    if (!t.is_paid) return false;

    const matchesSearch = t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         t.category_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPaymentMethod = selectedPaymentMethod === "all" || t.payment_method === selectedPaymentMethod;

    // Use payment_date if available, otherwise fall back to due_date, then date
    const paymentDateStr = t.payment_date || t.due_date || t.date;
    if (!paymentDateStr) return false;
    
    const [year, month, day] = paymentDateStr.split('-');
    const relevantDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));

    if (selectedMonth === "all") {
      return relevantDate.getFullYear().toString() === selectedYear && matchesSearch && matchesPaymentMethod;
    }

    return relevantDate.getMonth().toString() === selectedMonth && 
           relevantDate.getFullYear().toString() === selectedYear &&
           matchesSearch && 
           matchesPaymentMethod;
  });

  const totalPaid = paidTransactions.reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalIncome = paidTransactions.filter(t => t.type === 'receita').reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalExpense = paidTransactions.filter(t => t.type === 'despesa').reduce((sum, t) => sum + (t.amount || 0), 0);

  // Group by payment method
  const byPaymentMethod = {};
  paidTransactions.forEach(t => {
    const method = PAYMENT_METHODS[t.payment_method] || t.payment_method || "Não informado";
    if (!byPaymentMethod[method]) {
      byPaymentMethod[method] = { total: 0, count: 0 };
    }
    byPaymentMethod[method].total += t.amount || 0;
    byPaymentMethod[method].count += 1;
  });

  const handleExportCSV = () => {
    const headers = ['Data Pagamento', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Forma de Pagamento'];
    const rows = paidTransactions.map(t => {
      const dateStr = t.payment_date || t.date;
      const [year, month, day] = dateStr.split('-');
      const dateObj = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
      return [
        format(dateObj, 'dd/MM/yyyy'),
        t.type === 'receita' ? 'Receita' : 'Despesa',
        t.description,
        t.category_name || '',
        t.amount.toFixed(2).replace('.', ','),
        PAYMENT_METHODS[t.payment_method] || t.payment_method || ''
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const monthName = MONTHS.find(m => m.value === selectedMonth)?.label || 'todos';
    a.download = `pagamentos-realizados-${monthName}-${selectedYear}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const monthName = MONTHS.find(m => m.value === selectedMonth)?.label;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-xl">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Pagamentos Realizados</h1>
                <p className="text-gray-500">Consulte todos os pagamentos já realizados</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleExportCSV}
            variant="outline"
            className="gap-2 border-green-600 text-green-600 hover:bg-green-50"
          >
            <FileDown className="w-4 h-4" />
            Exportar CSV
          </Button>
        </motion.div>

        {/* Filters */}
        <Card className="border-0 shadow-lg bg-white">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar por descrição ou categoria..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>

              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MONTHS.map(month => (
                    <SelectItem key={month.value} value={month.value}>
                      {month.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-full md:w-28">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map(year => (
                    <SelectItem key={year} value={year}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedPaymentMethod} onValueChange={setSelectedPaymentMethod}>
                <SelectTrigger className="w-full md:w-52">
                  <SelectValue placeholder="Forma de Pagamento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as Formas</SelectItem>
                  {Object.entries(PAYMENT_METHODS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="pt-6">
              <p className="text-green-100 text-sm mb-1">Total Pago</p>
              <p className="text-2xl font-bold">{formatCurrency(totalPaid)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Receitas Recebidas</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Despesas Pagas</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpense)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Total de Transações</p>
              <p className="text-2xl font-bold text-blue-900">{paidTransactions.length}</p>
            </CardContent>
          </Card>
        </div>

        {/* Payment Method Summary */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Por Forma de Pagamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(byPaymentMethod)
                .sort(([,a], [,b]) => b.total - a.total)
                .map(([method, data]) => (
                  <div key={method} className="p-4 bg-slate-50 rounded-xl">
                    <p className="text-sm text-gray-600 mb-1">{method}</p>
                    <p className="text-xl font-bold text-blue-900">{formatCurrency(data.total)}</p>
                    <p className="text-xs text-gray-500 mt-1">{data.count} transações</p>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        {/* Transactions Table */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>
              Detalhamento - {selectedMonth === "all" ? `Ano ${selectedYear}` : `${monthName} ${selectedYear}`}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Forma de Pagamento</TableHead>
                    <TableHead className="text-right">Valor</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paidTransactions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                        Nenhum pagamento realizado encontrado
                      </TableCell>
                    </TableRow>
                  ) : (
                    paidTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            {(() => {
                              const dateStr = transaction.payment_date || transaction.date;
                              const [year, month, day] = dateStr.split('-');
                              return format(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)), 'dd/MM/yyyy');
                            })()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline"
                            className={transaction.type === 'receita' 
                              ? 'border-green-200 text-green-700 bg-green-50' 
                              : 'border-red-200 text-red-700 bg-red-50'
                            }
                          >
                            {transaction.type === 'receita' ? 'Receita' : 'Despesa'}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{transaction.description}</TableCell>
                        <TableCell>
                          {transaction.category_name && (
                            <div className="flex items-center gap-2">
                              {transaction.category_icon && <span>{transaction.category_icon}</span>}
                              {transaction.category_name}
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {PAYMENT_METHODS[transaction.payment_method] || transaction.payment_method || 'Não informado'}
                          </Badge>
                        </TableCell>
                        <TableCell className={`text-right font-bold ${
                          transaction.type === 'receita' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {formatCurrency(transaction.amount)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}