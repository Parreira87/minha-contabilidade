import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, startOfMonth, addMonths, isBefore, isAfter } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ArrowLeft, Plus, Target, PiggyBank, Building2, Pencil, Trash2, FileDown, CheckCircle, Circle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import FinancialProjectForm from "@/components/projects/FinancialProjectForm";

export default function FinancialProjects() {
  const [showForm, setShowForm] = useState(false);
  const [editingProject, setEditingProject] = useState(null);

  const queryClient = useQueryClient();

  const { data: projects = [] } = useQuery({
    queryKey: ['financial-projects'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.FinancialProject.filter({ created_by: user.email }, '-created_date');
    },
  });

  const { data: deposits = [] } = useQuery({
    queryKey: ['project-deposits'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.ProjectDeposit.filter({ created_by: user.email }, '-deposit_date');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.FinancialProject.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['financial-projects'] });
    },
  });

  const markDepositMutation = useMutation({
    mutationFn: async ({ project, month }) => {
      return base44.entities.ProjectDeposit.create({
        project_id: project.id,
        project_name: project.name,
        month: month,
        amount: project.monthly_amount,
        deposit_date: new Date().toISOString().split('T')[0],
        notes: ''
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project-deposits'] });
    },
  });

  const deleteDepositMutation = useMutation({
    mutationFn: (id) => base44.entities.ProjectDeposit.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project-deposits'] });
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleEdit = (project) => {
    setEditingProject(project);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este projeto?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingProject(null);
  };

  const handleSave = () => {
    queryClient.invalidateQueries({ queryKey: ['financial-projects'] });
  };

  const totalMonthlyAmount = projects
    .filter(p => p.is_active)
    .reduce((sum, p) => sum + (p.monthly_amount || 0), 0);

  const totalDeposited = deposits.reduce((sum, d) => sum + (d.amount || 0), 0);

  const projectsByStorage = projects.reduce((acc, p) => {
    const storage = p.storage_type === 'cofre' ? 'Cofre' : p.bank_name || 'Banco';
    if (!acc[storage]) acc[storage] = { total: 0, count: 0 };
    acc[storage].total += p.monthly_amount || 0;
    acc[storage].count += 1;
    return acc;
  }, {});

  const getMonthsForProject = (project) => {
    const months = [];
    const startDate = new Date('2026-01-01'); // Janeiro de 2026
    const endDate = new Date('2027-12-01'); // Dezembro de 2027

    let monthDate = startDate;
    while (isBefore(monthDate, endDate) || monthDate.getTime() === startOfMonth(endDate).getTime()) {
      const monthStr = format(monthDate, 'yyyy-MM');
      const deposit = deposits.find(d => d.project_id === project.id && d.month === monthStr);
      months.push({
        month: monthStr,
        deposit: deposit,
        isDeposited: !!deposit,
        isPast: isBefore(monthDate, startOfMonth(new Date()))
      });
      monthDate = addMonths(monthDate, 1);
    }
    return months;
  };

  const handleToggleDeposit = (project, month, deposit) => {
    if (deposit) {
      if (window.confirm('Deseja remover este depósito?')) {
        deleteDepositMutation.mutate(deposit.id);
      }
    } else {
      markDepositMutation.mutate({ project, month });
    }
  };

  const handleExportCSV = () => {
    const headers = ['Projeto', 'Mês', 'Valor', 'Data Depósito', 'Armazenamento', 'Banco', 'Observações'];
    const rows = deposits.map(d => {
      const project = projects.find(p => p.id === d.project_id);
      return [
        d.project_name,
        d.month,
        d.amount.toFixed(2).replace('.', ','),
        d.deposit_date,
        project?.storage_type === 'cofre' ? 'Cofre' : 'Banco',
        project?.bank_name || '',
        (d.notes || '').replace(/"/g, '""')
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `depositos-projetos-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-xl">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Projetos Financeiros</h1>
                <p className="text-gray-500">Planeje suas economias mensais</p>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={handleExportCSV}
              variant="outline"
              className="gap-2"
            >
              <FileDown className="w-4 h-4" />
              Exportar
            </Button>
            <Button 
              onClick={() => setShowForm(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Projeto
            </Button>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <Target className="w-8 h-8" />
                <div>
                  <p className="text-purple-100 text-sm">Meta Mensal</p>
                  <p className="text-2xl font-bold">{formatCurrency(totalMonthlyAmount)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Total Guardado</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(totalDeposited)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <PiggyBank className="w-8 h-8 text-orange-500" />
                <div>
                  <p className="text-gray-500 text-sm">Projetos Ativos</p>
                  <p className="text-2xl font-bold text-blue-900">
                    {projects.filter(p => p.is_active).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg bg-white">
            <CardContent className="pt-6">
              <p className="text-gray-500 text-sm mb-1">Depósitos Este Mês</p>
              <p className="text-2xl font-bold text-blue-900">
                {deposits.filter(d => d.month === format(new Date(), 'yyyy-MM')).length}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Storage Summary */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Por Tipo de Armazenamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(projectsByStorage).map(([storage, data]) => (
                <div key={storage} className="p-4 bg-slate-50 rounded-xl">
                  <p className="text-sm text-gray-600 mb-1">{storage}</p>
                  <p className="text-xl font-bold text-purple-600">{formatCurrency(data.total)}</p>
                  <p className="text-xs text-gray-500 mt-1">{data.count} projetos</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Projects with Timeline */}
        <div className="space-y-6">
          {projects.map((project) => {
            const months = getMonthsForProject(project);
            const totalProjectDeposits = deposits
              .filter(d => d.project_id === project.id)
              .reduce((sum, d) => sum + (d.amount || 0), 0);

            return (
              <Card key={project.id} className={`border-0 shadow-lg ${!project.is_active ? 'opacity-60' : ''}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-xl">{project.name}</CardTitle>
                        <Badge variant={project.is_active ? "default" : "secondary"}>
                          {project.is_active ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          {project.storage_type === 'cofre' ? (
                            <>
                              <PiggyBank className="w-4 h-4" />
                              <span>Cofre</span>
                            </>
                          ) : (
                            <>
                              <Building2 className="w-4 h-4" />
                              <span>{project.bank_name}</span>
                            </>
                          )}
                        </div>
                        <div>
                          <span className="font-semibold text-purple-600">{formatCurrency(project.monthly_amount)}</span> por mês
                        </div>
                        <div>
                          Total guardado: <span className="font-semibold text-green-600">{formatCurrency(totalProjectDeposits)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(project)}
                        className="h-8 w-8 text-gray-400 hover:text-blue-600"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(project.id)}
                        className="h-8 w-8 text-gray-400 hover:text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-500 mb-3">Histórico de Depósitos</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                      {months.map((m) => (
                        <motion.div
                          key={m.month}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button
                            variant={m.isDeposited ? "default" : "outline"}
                            className={`w-full h-auto py-3 px-2 flex flex-col gap-1 ${
                              m.isDeposited 
                                ? 'bg-green-600 hover:bg-green-700' 
                                : m.isPast 
                                  ? 'border-orange-300 text-orange-600 hover:bg-orange-50'
                                  : ''
                            }`}
                            onClick={() => handleToggleDeposit(project, m.month, m.deposit)}
                          >
                            {m.isDeposited ? (
                              <CheckCircle className="w-5 h-5" />
                            ) : (
                              <Circle className="w-5 h-5" />
                            )}
                            <span className="text-xs font-semibold">
                              {format(new Date(m.month + '-01'), 'MMM/yy', { locale: ptBR })}
                            </span>
                            {m.deposit && (
                              <span className="text-xs">
                                {format(new Date(m.deposit.deposit_date), 'dd/MM')}
                              </span>
                            )}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  {project.notes && (
                    <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-gray-500 mb-1">Observações</p>
                      <p className="text-sm text-gray-700">{project.notes}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>

        {projects.length === 0 && (
          <Card className="border-0 shadow-lg">
            <CardContent className="py-12 text-center">
              <Target className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <p className="text-gray-500 text-lg mb-4">Nenhum projeto financeiro cadastrado</p>
              <Button onClick={() => setShowForm(true)} className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Projeto
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Project Form Modal */}
        <FinancialProjectForm
          isOpen={showForm}
          onClose={handleCloseForm}
          onSave={handleSave}
          project={editingProject}
        />
      </div>
    </div>
  );
}