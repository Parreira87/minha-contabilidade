import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Upload, FileSpreadsheet, Check, X, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function Import() {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState([]);
  const [error, setError] = useState(null);
  const [imported, setImported] = useState(false);

  const queryClient = useQueryClient();

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: () => base44.entities.Category.list(),
  });

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setExtractedData([]);
      setError(null);
      setImported(false);
    }
  };

  const handleExtract = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);

    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
      file_url,
      json_schema: {
        type: "array",
        items: {
          type: "object",
          properties: {
            date: { type: "string", description: "Data no formato YYYY-MM-DD" },
            description: { type: "string", description: "Descrição do lançamento" },
            amount: { type: "number", description: "Valor do lançamento (positivo)" },
            type: { type: "string", enum: ["receita", "despesa"], description: "Tipo do lançamento" }
          }
        }
      }
    });

    setIsProcessing(false);

    if (result.status === "success" && result.output) {
      const dataWithDefaults = (Array.isArray(result.output) ? result.output : [result.output]).map((item, index) => ({
        ...item,
        id: index,
        category_id: "",
        category_name: "",
        payment_method: "pix",
        is_paid: false,
        selected: true
      }));
      setExtractedData(dataWithDefaults);
    } else {
      setError(result.details || "Erro ao processar arquivo");
    }
  };

  const handleCategoryChange = (index, categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    const newData = [...extractedData];
    newData[index] = {
      ...newData[index],
      category_id: categoryId,
      category_name: category?.name || ""
    };
    setExtractedData(newData);
  };

  const toggleSelection = (index) => {
    const newData = [...extractedData];
    newData[index].selected = !newData[index].selected;
    setExtractedData(newData);
  };

  const handleImport = async () => {
    setIsProcessing(true);

    const selectedItems = extractedData.filter(item => item.selected);
    const transactionsToCreate = selectedItems.map(item => ({
      date: item.date,
      description: item.description,
      amount: Math.abs(item.amount),
      type: item.type,
      category_id: item.category_id,
      category_name: item.category_name,
      payment_method: item.payment_method,
      is_paid: item.is_paid
    }));

    await base44.entities.Transaction.bulkCreate(transactionsToCreate);

    queryClient.invalidateQueries({ queryKey: ['transactions'] });
    setIsProcessing(false);
    setImported(true);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(Math.abs(value));
  };

  const selectedCount = extractedData.filter(d => d.selected).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <Link to={createPageUrl("Dashboard")}>
            <Button variant="outline" size="icon" className="bg-white">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-100 rounded-xl">
              <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Importar Planilha</h1>
              <p className="text-gray-500">Importe seus lançamentos de uma planilha</p>
            </div>
          </div>
        </motion.div>

        {!imported ? (
          <>
            {/* Upload Card */}
            <Card className="border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Upload de Arquivo</CardTitle>
                <CardDescription>
                  Selecione uma planilha CSV ou Excel com suas transações
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center">
                  <Input
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                  />
                  <Label htmlFor="file-upload" className="cursor-pointer">
                    <div className="flex flex-col items-center gap-3">
                      <div className="p-4 bg-gray-100 rounded-full">
                        <Upload className="w-8 h-8 text-gray-500" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-700">
                          {file ? file.name : "Clique para selecionar um arquivo"}
                        </p>
                        <p className="text-sm text-gray-500">CSV ou Excel (até 10MB)</p>
                      </div>
                    </div>
                  </Label>
                </div>

                {file && extractedData.length === 0 && (
                  <Button
                    onClick={handleExtract}
                    disabled={isProcessing}
                    className="w-full bg-blue-900 hover:bg-blue-800"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processando...
                      </>
                    ) : (
                      <>
                        <FileSpreadsheet className="w-4 h-4 mr-2" />
                        Extrair Dados
                      </>
                    )}
                  </Button>
                )}

                {error && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-700">
                    {error}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Preview Table */}
            {extractedData.length > 0 && (
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Pré-visualização</CardTitle>
                      <CardDescription>
                        {selectedCount} de {extractedData.length} lançamentos selecionados
                      </CardDescription>
                    </div>
                    <Button
                      onClick={handleImport}
                      disabled={isProcessing || selectedCount === 0}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Importando...
                        </>
                      ) : (
                        <>
                          <Check className="w-4 h-4 mr-2" />
                          Importar Selecionados
                        </>
                      )}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12"></TableHead>
                          <TableHead>Data</TableHead>
                          <TableHead>Descrição</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead>Categoria</TableHead>
                          <TableHead className="text-right">Valor</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {extractedData.map((item, index) => (
                          <TableRow key={index} className={!item.selected ? 'opacity-50' : ''}>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => toggleSelection(index)}
                                className={item.selected ? 'text-green-600' : 'text-gray-400'}
                              >
                                {item.selected ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                              </Button>
                            </TableCell>
                            <TableCell>{item.date}</TableCell>
                            <TableCell className="max-w-xs truncate">{item.description}</TableCell>
                            <TableCell>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                item.type === 'receita' 
                                  ? 'bg-green-100 text-green-700' 
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {item.type === 'receita' ? 'Receita' : 'Despesa'}
                              </span>
                            </TableCell>
                            <TableCell>
                              <Select
                                value={item.category_id}
                                onValueChange={(v) => handleCategoryChange(index, v)}
                              >
                                <SelectTrigger className="w-32">
                                  <SelectValue placeholder="Categoria" />
                                </SelectTrigger>
                                <SelectContent>
                                  {categories
                                    .filter(c => c.type === item.type)
                                    .map(cat => (
                                      <SelectItem key={cat.id} value={cat.id}>
                                        {cat.name}
                                      </SelectItem>
                                    ))
                                  }
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell className={`text-right font-medium ${
                              item.type === 'receita' ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {item.type === 'receita' ? '+' : '-'}{formatCurrency(item.amount)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        ) : (
          <Card className="border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Importação Concluída!</h2>
              <p className="text-gray-500 mb-6">
                {selectedCount} lançamentos foram importados com sucesso.
              </p>
              <div className="flex gap-3 justify-center">
                <Link to={createPageUrl("Transactions")}>
                  <Button className="bg-blue-900 hover:bg-blue-800">
                    Ver Lançamentos
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  onClick={() => {
                    setFile(null);
                    setExtractedData([]);
                    setImported(false);
                  }}
                >
                  Importar Mais
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}