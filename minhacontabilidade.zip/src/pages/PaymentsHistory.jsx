import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ArrowLeft, CheckCircle, FileDown, FileSpreadsheet } from "lucide-react";
import { motion } from "framer-motion";

const MONTHS = [
  { value: "0", label: "Janeiro" },
  { value: "1", label: "Fevereiro" },
  { value: "2", label: "Março" },
  { value: "3", label: "Abril" },
  { value: "4", label: "Maio" },
  { value: "5", label: "Junho" },
  { value: "6", label: "Julho" },
  { value: "7", label: "Agosto" },
  { value: "8", label: "Setembro" },
  { value: "9", label: "Outubro" },
  { value: "10", label: "Novembro" },
  { value: "11", label: "Dezembro" }
];

const PAYMENT_METHODS = {
  dinheiro: "Dinheiro",
  pix: "PIX",
  cartao_credito: "Cartão de Crédito",
  cartao_debito: "Cartão de Débito",
  transferencia: "Transferência",
  boleto: "Boleto"
};

export default function PaymentsHistory() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth().toString());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [filterType, setFilterType] = useState("all");

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 5 }, (_, i) => (currentYear - 2 + i).toString());

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => base44.entities.Transaction.list('-date'),
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  // Filter only paid transactions
  const paidTransactions = transactions
    .filter(t => t.is_paid)
    .filter(t => {
      const date = new Date(t.date);
      return date.getMonth().toString() === selectedMonth && 
             date.getFullYear().toString() === selectedYear;
    })
    .filter(t => filterType === "all" || t.type === filterType);

  const totalPaid = paidTransactions.reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalIncome = paidTransactions.filter(t => t.type === 'receita').reduce((sum, t) => sum + t.amount, 0);
  const totalExpense = paidTransactions.filter(t => t.type === 'despesa').reduce((sum, t) => sum + t.amount, 0);

  // Group by payment method
  const byPaymentMethod = {};
  paidTransactions.forEach(t => {
    const method = t.payment_method || 'outros';
    if (!byPaymentMethod[method]) {
      byPaymentMethod[method] = { count: 0, total: 0 };
    }
    byPaymentMethod[method].count += 1;
    byPaymentMethod[method].total += t.amount || 0;
  });

  const monthName = MONTHS.find(m => m.value === selectedMonth)?.label;

  const generateCSV = () => {
    const headers = ['Data Pagamento', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Forma de Pagamento'];
    const rows = paidTransactions.map(t => [
      format(new Date(t.date), 'dd/MM/yyyy'),
      t.type === 'receita' ? 'Receita' : 'Despesa',
      t.description,
      t.category_name || '',
      t.amount.toFixed(2).replace('.', ','),
      PAYMENT_METHODS[t.payment_method] || t.payment_method || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pagamentos-realizados-${monthName}-${selectedYear}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  const generateTXT = () => {
    let content = `===========================================\n`;
    content += `RELATÓRIO DE PAGAMENTOS REALIZADOS\n`;
    content += `${monthName} ${selectedYear}\n`;
    content += `===========================================\n\n`;

    content += `RESUMO:\n`;
    content += `Total Receitas Recebidas: ${formatCurrency(totalIncome)}\n`;
    content += `Total Despesas Pagas: ${formatCurrency(totalExpense)}\n`;
    content += `Total Geral: ${formatCurrency(totalPaid)}\n\n`;

    content += `POR FORMA DE PAGAMENTO:\n`;
    Object.entries(byPaymentMethod)
      .sort(([,a], [,b]) => b.total - a.total)
      .forEach(([method, data]) => {
        content += `${PAYMENT_METHODS[method] || method}: ${data.count} transações - ${formatCurrency(data.total)}\n`;
      });

    content += `\n\nDETALHAMENTO:\n`;
    content += `===========================================\n\n`;

    paidTransactions.forEach((tx, index) => {
      content += `${index + 1}. ${tx.description}\n`;
      content += `   Data: ${format(new Date(tx.date), 'dd/MM/yyyy', { locale: ptBR })}\n`;
      content += `   Tipo: ${tx.type === 'receita' ? 'Receita' : 'Despesa'}\n`;
      content += `   Valor: ${formatCurrency(tx.amount)}\n`;
      content += `   Forma de Pagamento: ${PAYMENT_METHODS[tx.payment_method] || tx.payment_method || 'Não informado'}\n`;
      content += `   Categoria: ${tx.category_name || 'Sem categoria'}\n\n`;
    });

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio-pagamentos-${monthName}-${selectedYear}.txt`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-green-100 rounded-xl">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Pagamentos Realizados</h1>
                <p className="text-gray-500">Histórico de pagamentos e recebimentos</p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Button onClick={generateCSV} variant="outline" className="gap-2 border-green-600 text-green-600">
              <FileSpreadsheet className="w-4 h-4" />
              CSV
            </Button>
            <Button onClick={generateTXT} variant="outline" className="gap-2">
              <FileDown className="w-4 h-4" />
              TXT
            </Button>

            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-36 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MONTHS.map(month => (
                  <SelectItem key={month.value} value={month.value}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="w-24 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-gray-500 mb-1">Receitas Recebidas</p>
              <p className="text-2xl font-bold text-green-600">{formatCurrency(totalIncome)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-gray-500 mb-1">Despesas Pagas</p>
              <p className="text-2xl font-bold text-red-600">{formatCurrency(totalExpense)}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-lg">
            <CardContent className="p-6">
              <p className="text-sm text-gray-500 mb-1">Total Movimentado</p>
              <p className="text-2xl font-bold text-blue-900">{formatCurrency(totalPaid)}</p>
            </CardContent>
          </Card>
        </div>

        {/* Payment Methods Summary */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Por Forma de Pagamento</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Forma de Pagamento</TableHead>
                  <TableHead className="text-center">Quantidade</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(byPaymentMethod)
                  .sort(([,a], [,b]) => b.total - a.total)
                  .map(([method, data]) => {
                    const percentage = totalPaid > 0 ? (data.total / totalPaid * 100).toFixed(1) : 0;
                    return (
                      <TableRow key={method}>
                        <TableCell className="font-medium">
                          {PAYMENT_METHODS[method] || method}
                        </TableCell>
                        <TableCell className="text-center">{data.count}</TableCell>
                        <TableCell className="text-right font-semibold">
                          {formatCurrency(data.total)}
                        </TableCell>
                        <TableCell className="text-right text-gray-500">
                          {percentage}%
                        </TableCell>
                      </TableRow>
                    );
                  })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Filter */}
        <div className="flex gap-2">
          <Button
            variant={filterType === "all" ? "default" : "outline"}
            onClick={() => setFilterType("all")}
            className={filterType === "all" ? "bg-blue-900" : ""}
          >
            Todos
          </Button>
          <Button
            variant={filterType === "receita" ? "default" : "outline"}
            onClick={() => setFilterType("receita")}
            className={filterType === "receita" ? "bg-green-600" : ""}
          >
            Receitas
          </Button>
          <Button
            variant={filterType === "despesa" ? "default" : "outline"}
            onClick={() => setFilterType("despesa")}
            className={filterType === "despesa" ? "bg-red-600" : ""}
          >
            Despesas
          </Button>
        </div>

        {/* Transactions Table */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Detalhamento de Pagamentos</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Categoria</TableHead>
                  <TableHead>Forma de Pagamento</TableHead>
                  <TableHead className="text-right">Valor</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paidTransactions.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell>
                      {format(new Date(tx.date), 'dd/MM/yyyy')}
                    </TableCell>
                    <TableCell className="font-medium">{tx.description}</TableCell>
                    <TableCell>{tx.category_name || '-'}</TableCell>
                    <TableCell>{PAYMENT_METHODS[tx.payment_method] || tx.payment_method || '-'}</TableCell>
                    <TableCell className={`text-right font-semibold ${
                      tx.type === 'receita' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {tx.type === 'receita' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            {paidTransactions.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                Nenhum pagamento realizado neste período
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}