import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  ArrowLeft, 
  Plus, 
  Repeat, 
  Pencil, 
  Trash2, 
  Play, 
  Pause,
  CheckCircle,
  Calendar
} from "lucide-react";
import RecurringForm from "@/components/recurring/RecurringForm";
import { motion, AnimatePresence } from "framer-motion";

const FREQUENCY_LABELS = {
  semanal: "Semanal",
  quinzenal: "Quinzenal",
  mensal: "Mensal",
  trimestral: "Trimestral",
  semestral: "Semestral",
  anual: "Anual"
};

export default function RecurringTransactions() {
  const [showForm, setShowForm] = useState(false);
  const [editingRecurring, setEditingRecurring] = useState(null);
  const [filterType, setFilterType] = useState("all");

  const queryClient = useQueryClient();

  const { data: recurrings = [] } = useQuery({
    queryKey: ['recurring-transactions'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.RecurringTransaction.filter({ created_by: user.email }, '-created_date');
    },
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const user = await base44.auth.me();
      return base44.entities.Category.filter({ created_by: user.email });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.RecurringTransaction.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurring-transactions'] });
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, is_active }) => 
      base44.entities.RecurringTransaction.update(id, { is_active }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recurring-transactions'] });
    },
  });

  const handleEdit = (recurring) => {
    setEditingRecurring(recurring);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir esta recorrência?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingRecurring(null);
  };

  const handleSave = () => {
    queryClient.invalidateQueries({ queryKey: ['recurring-transactions'] });
  };

  const handleToggleActive = (recurring) => {
    toggleActiveMutation.mutate({
      id: recurring.id,
      is_active: !recurring.is_active
    });
  };

  const filteredRecurrings = recurrings.filter(r => 
    filterType === "all" || r.type === filterType
  );

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-4 md:p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" size="icon" className="bg-white">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 rounded-xl">
                <Repeat className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-blue-900">Transações Recorrentes</h1>
                <p className="text-gray-500">Despesas e receitas fixas</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={() => setShowForm(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Recorrência
          </Button>
        </motion.div>

        {/* Filter */}
        <Tabs value={filterType} onValueChange={setFilterType}>
          <TabsList className="bg-white">
            <TabsTrigger value="all">Todas</TabsTrigger>
            <TabsTrigger value="receita" className="data-[state=active]:bg-green-100 data-[state=active]:text-green-700">
              Receitas
            </TabsTrigger>
            <TabsTrigger value="despesa" className="data-[state=active]:bg-red-100 data-[state=active]:text-red-700">
              Despesas
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Recurring List */}
        <div className="space-y-3">
          <AnimatePresence>
            {filteredRecurrings.map((recurring, index) => (
              <motion.div
                key={recurring.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className={`border-0 shadow-sm hover:shadow-md transition-all ${
                  !recurring.is_active ? 'bg-gray-50 opacity-70' : 'bg-white'
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-4 flex-1">
                        <div className={`p-2 rounded-full ${
                          recurring.type === 'receita' 
                            ? 'bg-green-100' 
                            : 'bg-red-100'
                        }`}>
                          <Repeat className={`w-5 h-5 ${
                            recurring.type === 'receita' ? 'text-green-600' : 'text-red-600'
                          }`} />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <p className="font-semibold text-gray-800">{recurring.description}</p>
                            {recurring.auto_confirm && (
                              <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Auto
                              </Badge>
                            )}
                            {!recurring.is_active && (
                              <Badge variant="outline" className="text-xs bg-gray-100 text-gray-600">
                                Pausada
                              </Badge>
                            )}
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-2 text-sm">
                            <Badge variant="secondary">
                              <Calendar className="w-3 h-3 mr-1" />
                              {FREQUENCY_LABELS[recurring.frequency]} - Dia {recurring.day_of_month}
                            </Badge>
                            {recurring.category_name && (
                              <Badge variant="secondary">
                                {recurring.category_name}
                              </Badge>
                            )}
                            <span className="text-xs text-gray-500">
                              Início: {new Date(recurring.start_date).toLocaleDateString('pt-BR')}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <p className={`font-bold text-lg ${
                            recurring.type === 'receita' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {recurring.type === 'receita' ? '+' : '-'}{formatCurrency(recurring.amount)}
                          </p>
                        </div>
                        
                        <div className="flex flex-col gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleToggleActive(recurring)}
                            className={`h-8 w-8 ${
                              recurring.is_active 
                                ? 'text-orange-500 hover:text-orange-700' 
                                : 'text-green-500 hover:text-green-700'
                            }`}
                          >
                            {recurring.is_active ? (
                              <Pause className="w-4 h-4" />
                            ) : (
                              <Play className="w-4 h-4" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(recurring)}
                            className="h-8 w-8 text-gray-500 hover:text-blue-600"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(recurring.id)}
                            className="h-8 w-8 text-gray-500 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>

          {filteredRecurrings.length === 0 && (
            <Card className="p-12 text-center border-0 shadow-lg">
              <Repeat className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500 text-lg mb-2">Nenhuma recorrência cadastrada</p>
              <p className="text-gray-400 text-sm mb-6">
                Crie transações recorrentes para automatizar seus lançamentos mensais
              </p>
              <Button onClick={() => setShowForm(true)} className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeira Recorrência
              </Button>
            </Card>
          )}
        </div>

        {/* Form Modal */}
        <RecurringForm
          isOpen={showForm}
          onClose={handleCloseForm}
          onSave={handleSave}
          recurring={editingRecurring}
          categories={categories}
        />
      </div>
    </div>
  );
}