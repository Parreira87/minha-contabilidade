import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, 
  CalendarDays, 
  Receipt, 
  Tag, 
  FileText, 
  Settings, 
  Menu, 
  X,
  LogOut,
  Upload,
  Repeat,
  Eye,
  EyeOff,
  CheckCircle,
  Target,
  CreditCard as CreditCardIcon,
  ShoppingCart
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { base44 } from "@/api/base44Client";

const NAV_ITEMS = [
  { name: "Dashboard", icon: LayoutDashboard, page: "Dashboard" },
  { name: "Lançamentos", icon: Receipt, page: "Transactions" },
  { name: "Cartões de Crédito", icon: CreditCardIcon, page: "CreditCards" },
  { name: "Gastos com Mercado", icon: ShoppingCart, page: "GroceryExpenses" },
  { name: "Pagamentos Realizados", icon: CheckCircle, page: "PaidTransactions" },
  { name: "Projetos Financeiros", icon: Target, page: "FinancialProjects" },
  { name: "Categorias", icon: Tag, page: "Categories" },
  { name: "Relatórios", icon: FileText, page: "Reports" },
  { name: "Importar", icon: Upload, page: "Import" },
  { name: "Configurações", icon: Settings, page: "Settings" }
];

export default function Layout({ children, currentPageName }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [privateMode, setPrivateMode] = useState(false);
  const location = useLocation();

  // Load private mode from localStorage
  React.useEffect(() => {
    const saved = localStorage.getItem('privateMode');
    if (saved) setPrivateMode(saved === 'true');
  }, []);

  const handleLogout = () => {
    base44.auth.logout();
  };

  const togglePrivateMode = () => {
    const newMode = !privateMode;
    setPrivateMode(newMode);
    localStorage.setItem('privateMode', newMode.toString());
  };

  // Provide private mode to children via context
  React.useEffect(() => {
    window.privateModeEnabled = privateMode;
    window.dispatchEvent(new CustomEvent('privateModeChanged', { detail: privateMode }));
  }, [privateMode]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col fixed left-0 top-0 h-screen w-64 bg-white border-r border-gray-100 shadow-sm z-50">
        {/* Logo */}
        <div className="p-4 border-b border-gray-100">
          <Link to={createPageUrl("Dashboard")} className="flex items-center gap-3">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6844a67bb310be18a8ed5e4d/5445de869_ChatGPTImage30dedezde202519_59_17.png"
              alt="Logo"
              className="w-10 h-10 object-contain"
            />
            <div>
              <h1 className="text-base font-bold text-blue-900 leading-tight">Minha</h1>
              <p className="text-xs text-orange-500 font-semibold -mt-0.5">Contabilidade</p>
            </div>
          </Link>
        </div>

        {/* Navigation with custom scrollbar */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-0.5 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent hover:scrollbar-thumb-gray-400">
          {NAV_ITEMS.map((item) => {
            const isActive = currentPageName === item.page;
            return (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all ${
                  isActive 
                    ? 'bg-blue-900 text-white shadow-lg' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-blue-900'
                }`}
              >
                <item.icon className="w-4 h-4 flex-shrink-0" />
                <span className="font-medium text-sm">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* Privacy Toggle & Logout */}
        <div className="p-2 border-t border-gray-100 space-y-1">
          <Button 
            variant="ghost" 
            size="sm"
            className={`w-full justify-start h-9 ${
              privateMode 
                ? 'text-purple-600 hover:text-purple-700 hover:bg-purple-50 bg-purple-50' 
                : 'text-gray-600 hover:text-purple-600 hover:bg-purple-50'
            }`}
            onClick={togglePrivateMode}
          >
            {privateMode ? (
              <>
                <EyeOff className="w-4 h-4 mr-2" />
                Modo Discreto
              </>
            ) : (
              <>
                <Eye className="w-4 h-4 mr-2" />
                Modo Normal
              </>
            )}
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className="w-full justify-start h-9 text-gray-600 hover:text-red-600 hover:bg-red-50"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>

        {/* Footer Info */}
        <div className="px-3 py-1.5 border-t border-gray-100 bg-gray-50">
          <p className="text-[10px] text-gray-600 text-center leading-tight">
            Desenvolvido por<br />
            <span className="font-semibold text-blue-900">Adriano Parreira TI</span>
          </p>
          <p className="text-[9px] text-gray-500 text-center mt-0.5">Versão 1.0 • 2025 • Conforme LGPD</p>
        </div>
        </aside>

      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-white border-b border-gray-100 shadow-sm z-50">
        <div className="flex items-center justify-between h-full px-4">
          <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6844a67bb310be18a8ed5e4d/5445de869_ChatGPTImage30dedezde202519_59_17.png"
              alt="Logo"
              className="w-10 h-10 object-contain"
            />
            <span className="font-bold text-blue-900">Minha Contabilidade</span>
          </Link>

          <div className="flex items-center gap-2">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-0">
              <div className="flex flex-col h-full">
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <img 
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_6844a67bb310be18a8ed5e4d/5445de869_ChatGPTImage30dedezde202519_59_17.png"
                      alt="Logo"
                      className="w-12 h-12 object-contain"
                    />
                    <div>
                      <h1 className="text-lg font-bold text-blue-900">Minha</h1>
                      <p className="text-sm text-orange-500 font-semibold -mt-1">Contabilidade</p>
                    </div>
                  </div>
                </div>

                <nav className="flex-1 p-4 space-y-1">
                  {NAV_ITEMS.map((item) => {
                    const isActive = currentPageName === item.page;
                    return (
                      <Link
                        key={item.page}
                        to={createPageUrl(item.page)}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                          isActive 
                            ? 'bg-blue-900 text-white' 
                            : 'text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <item.icon className="w-5 h-5" />
                        <span className="font-medium">{item.name}</span>
                      </Link>
                    );
                  })}
                </nav>

                <div className="p-4 border-t border-gray-100 space-y-2">
                  <Button 
                    variant="ghost" 
                    className={`w-full justify-start ${
                      privateMode 
                        ? 'text-purple-600 hover:text-purple-700' 
                        : 'text-gray-600 hover:text-purple-600'
                    }`}
                    onClick={togglePrivateMode}
                  >
                    {privateMode ? (
                      <>
                        <EyeOff className="w-5 h-5 mr-3" />
                        Modo Discreto
                      </>
                    ) : (
                      <>
                        <Eye className="w-5 h-5 mr-3" />
                        Modo Normal
                      </>
                    )}
                  </Button>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-gray-600 hover:text-red-600"
                    onClick={handleLogout}
                  >
                    <LogOut className="w-5 h-5 mr-3" />
                    Sair
                  </Button>
                </div>

                {/* Footer Info Mobile */}
                <div className="px-4 py-3 border-t border-gray-100 bg-gray-50">
                  <p className="text-xs text-gray-600 text-center mb-1">
                    Desenvolvido por<br />
                    <span className="font-semibold text-blue-900">Adriano Parreira TI</span><br />
                    Sistemas Inteligentes
                  </p>
                  <p className="text-xs text-gray-500 text-center mb-1">Versão 1.0 • 2025</p>
                  <p className="text-xs text-green-700 text-center font-medium">✓ Conforme LGPD</p>
                </div>
                </div>
                </SheetContent>
                </Sheet>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 lg:pt-0 min-h-screen">
        {children}
      </main>
    </div>
  );
}