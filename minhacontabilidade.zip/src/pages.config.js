import Categories from './pages/Categories';
import CreditCards from './pages/CreditCards';
import Dashboard from './pages/Dashboard';
import FinancialProjects from './pages/FinancialProjects';
import GroceryExpenses from './pages/GroceryExpenses';
import Import from './pages/Import';
import PaidTransactions from './pages/PaidTransactions';
import PaymentsHistory from './pages/PaymentsHistory';
import RecurringTransactions from './pages/RecurringTransactions';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import Transactions from './pages/Transactions';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Categories": Categories,
    "CreditCards": CreditCards,
    "Dashboard": Dashboard,
    "FinancialProjects": FinancialProjects,
    "GroceryExpenses": GroceryExpenses,
    "Import": Import,
    "PaidTransactions": PaidTransactions,
    "PaymentsHistory": PaymentsHistory,
    "RecurringTransactions": RecurringTransactions,
    "Reports": Reports,
    "Settings": Settings,
    "Transactions": Transactions,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};