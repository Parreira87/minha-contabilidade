import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user || user.role !== 'admin') {
            return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
        }

        // Get all active recurring transactions
        const recurrings = await base44.asServiceRole.entities.RecurringTransaction.list();
        const activeRecurrings = recurrings.filter(r => r.is_active);

        if (activeRecurrings.length === 0) {
            return Response.json({ 
                message: 'No active recurring transactions found',
                generated: 0
            });
        }

        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = currentDate.getMonth();
        
        // Get existing transactions for this month
        const existingTransactions = await base44.asServiceRole.entities.Transaction.list();
        
        const transactionsToCreate = [];
        const notificationsToSend = [];

        for (const recurring of activeRecurrings) {
            // Check if end_date has passed
            if (recurring.end_date && new Date(recurring.end_date) < currentDate) {
                continue;
            }

            // Calculate next occurrence date
            let nextDate;
            
            if (recurring.frequency === 'mensal') {
                nextDate = new Date(currentYear, currentMonth, recurring.day_of_month);
            } else if (recurring.frequency === 'semanal') {
                // Skip for now, needs more complex logic
                continue;
            } else if (recurring.frequency === 'quinzenal') {
                // Skip for now, needs more complex logic
                continue;
            } else if (recurring.frequency === 'trimestral') {
                const startMonth = new Date(recurring.start_date).getMonth();
                if ((currentMonth - startMonth) % 3 === 0) {
                    nextDate = new Date(currentYear, currentMonth, recurring.day_of_month);
                }
            } else if (recurring.frequency === 'semestral') {
                const startMonth = new Date(recurring.start_date).getMonth();
                if ((currentMonth - startMonth) % 6 === 0) {
                    nextDate = new Date(currentYear, currentMonth, recurring.day_of_month);
                }
            } else if (recurring.frequency === 'anual') {
                const startDate = new Date(recurring.start_date);
                if (currentMonth === startDate.getMonth()) {
                    nextDate = new Date(currentYear, currentMonth, recurring.day_of_month);
                }
            }

            if (!nextDate) continue;

            // Check if transaction already exists for this month
            const alreadyExists = existingTransactions.some(t => {
                const tDate = new Date(t.date);
                return t.description === recurring.description &&
                       t.amount === recurring.amount &&
                       tDate.getMonth() === nextDate.getMonth() &&
                       tDate.getFullYear() === nextDate.getFullYear();
            });

            if (alreadyExists) continue;

            // Check if should be created within next 3 days
            const daysUntilDue = Math.floor((nextDate - currentDate) / (1000 * 60 * 60 * 24));
            
            if (daysUntilDue >= 0 && daysUntilDue <= 3) {
                const newTransaction = {
                    type: recurring.type,
                    date: nextDate.toISOString().split('T')[0],
                    due_date: nextDate.toISOString().split('T')[0],
                    description: recurring.description,
                    category_id: recurring.category_id,
                    category_name: recurring.category_name,
                    amount: recurring.amount,
                    payment_method: recurring.payment_method,
                    is_paid: false,
                    notes: `Gerado automaticamente de recorrência: ${recurring.frequency}`
                };

                if (recurring.auto_confirm) {
                    // Create automatically
                    await base44.asServiceRole.entities.Transaction.create(newTransaction);
                    transactionsToCreate.push(newTransaction);
                } else {
                    // Add to notifications for user approval
                    notificationsToSend.push({
                        recurring,
                        transaction: newTransaction
                    });
                }
            }
        }

        return Response.json({
            success: true,
            generated: transactionsToCreate.length,
            pending_approval: notificationsToSend.length,
            transactions: transactionsToCreate,
            notifications: notificationsToSend
        });

    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});