import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import { jsPDF } from 'npm:jspdf@2.5.1';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();

        if (!user) {
            return Response.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const { month, year, type } = await req.json();

        // Fetch transactions
        const transactions = await base44.entities.Transaction.list('-due_date');
        
        // Filter by month and year if provided
        const filteredTransactions = transactions.filter(t => {
            if (month && year) {
                const date = new Date(t.date);
                return date.getMonth() === parseInt(month) && 
                       date.getFullYear() === parseInt(year);
            }
            return true;
        }).filter(t => {
            if (type === 'receita' || type === 'despesa') {
                return t.type === type;
            }
            return true;
        });

        // Sort by due date
        filteredTransactions.sort((a, b) => {
            const dateA = new Date(a.due_date || a.date);
            const dateB = new Date(b.due_date || b.date);
            return dateA - dateB;
        });

        const doc = new jsPDF();
        let yPosition = 20;

        // Helper function to check if we need a new page
        const checkNewPage = () => {
            if (yPosition > 270) {
                doc.addPage();
                yPosition = 20;
            }
        };

        // Title
        doc.setFontSize(18);
        doc.setFont(undefined, 'bold');
        doc.text('Relatório Financeiro', 105, yPosition, { align: 'center' });
        yPosition += 10;

        // Date and type info
        doc.setFontSize(11);
        doc.setFont(undefined, 'normal');
        const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 
                           'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
        const period = month && year ? `${monthNames[parseInt(month)]} ${year}` : 'Todos os Períodos';
        const typeLabel = type === 'receita' ? 'Receitas' : type === 'despesa' ? 'Despesas' : 'Receitas e Despesas';
        doc.text(`Período: ${period}`, 105, yPosition, { align: 'center' });
        yPosition += 6;
        doc.text(`Tipo: ${typeLabel}`, 105, yPosition, { align: 'center' });
        yPosition += 6;
        doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')}`, 105, yPosition, { align: 'center' });
        yPosition += 15;

        // Calculate totals
        const totalReceitas = filteredTransactions
            .filter(t => t.type === 'receita')
            .reduce((sum, t) => sum + (t.amount || 0), 0);
        
        const totalDespesas = filteredTransactions
            .filter(t => t.type === 'despesa')
            .reduce((sum, t) => sum + (t.amount || 0), 0);

        const saldo = totalReceitas - totalDespesas;

        // Summary box
        doc.setFillColor(240, 240, 240);
        doc.rect(15, yPosition, 180, 30, 'F');
        
        doc.setFontSize(10);
        doc.setFont(undefined, 'bold');
        doc.text('RESUMO', 20, yPosition + 7);
        
        doc.setFont(undefined, 'normal');
        doc.text(`Total Receitas: R$ ${totalReceitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 20, yPosition + 15);
        doc.text(`Total Despesas: R$ ${totalDespesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 20, yPosition + 22);
        
        doc.setFont(undefined, 'bold');
        const saldoColor = saldo >= 0 ? [0, 128, 0] : [255, 0, 0];
        doc.setTextColor(...saldoColor);
        doc.text(`Saldo: R$ ${saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 120, yPosition + 22);
        doc.setTextColor(0, 0, 0);
        
        yPosition += 40;

        // Group by type
        const receitas = filteredTransactions.filter(t => t.type === 'receita');
        const despesas = filteredTransactions.filter(t => t.type === 'despesa');

        // Render Receitas
        if ((type !== 'despesa') && receitas.length > 0) {
            checkNewPage();
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(0, 128, 0);
            doc.text('RECEITAS', 15, yPosition);
            doc.setTextColor(0, 0, 0);
            yPosition += 8;

            // Table header
            doc.setFillColor(34, 197, 94);
            doc.rect(15, yPosition, 180, 8, 'F');
            doc.setFontSize(9);
            doc.setTextColor(255, 255, 255);
            doc.setFont(undefined, 'bold');
            doc.text('Vencimento', 17, yPosition + 5);
            doc.text('Descrição', 45, yPosition + 5);
            doc.text('Status', 130, yPosition + 5);
            doc.text('Valor', 170, yPosition + 5);
            doc.setTextColor(0, 0, 0);
            yPosition += 10;

            doc.setFont(undefined, 'normal');
            receitas.forEach((t, index) => {
                checkNewPage();
                
                const bgColor = index % 2 === 0 ? [249, 250, 251] : [255, 255, 255];
                doc.setFillColor(...bgColor);
                doc.rect(15, yPosition - 2, 180, 7, 'F');

                doc.setFontSize(8);
                const dueDate = t.due_date ? new Date(t.due_date).toLocaleDateString('pt-BR') : '-';
                doc.text(dueDate, 17, yPosition + 3);
                
                let description = t.description || '';
                if (t.total_installments > 1) {
                    description += ` (${t.installment_number}/${t.total_installments})`;
                }
                if (description.length > 35) {
                    description = description.substring(0, 35) + '...';
                }
                doc.text(description, 45, yPosition + 3);
                
                doc.text(t.is_paid ? 'Pago' : 'Pendente', 130, yPosition + 3);
                doc.text(`R$ ${(t.amount || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 170, yPosition + 3);
                
                yPosition += 7;
            });

            yPosition += 5;
        }

        // Render Despesas
        if ((type !== 'receita') && despesas.length > 0) {
            checkNewPage();
            doc.setFontSize(14);
            doc.setFont(undefined, 'bold');
            doc.setTextColor(239, 68, 68);
            doc.text('DESPESAS', 15, yPosition);
            doc.setTextColor(0, 0, 0);
            yPosition += 8;

            // Table header
            doc.setFillColor(239, 68, 68);
            doc.rect(15, yPosition, 180, 8, 'F');
            doc.setFontSize(9);
            doc.setTextColor(255, 255, 255);
            doc.setFont(undefined, 'bold');
            doc.text('Vencimento', 17, yPosition + 5);
            doc.text('Descrição', 45, yPosition + 5);
            doc.text('Status', 130, yPosition + 5);
            doc.text('Valor', 170, yPosition + 5);
            doc.setTextColor(0, 0, 0);
            yPosition += 10;

            doc.setFont(undefined, 'normal');
            despesas.forEach((t, index) => {
                checkNewPage();
                
                const bgColor = index % 2 === 0 ? [249, 250, 251] : [255, 255, 255];
                doc.setFillColor(...bgColor);
                doc.rect(15, yPosition - 2, 180, 7, 'F');

                doc.setFontSize(8);
                const dueDate = t.due_date ? new Date(t.due_date).toLocaleDateString('pt-BR') : '-';
                doc.text(dueDate, 17, yPosition + 3);
                
                let description = t.description || '';
                if (t.total_installments > 1) {
                    description += ` (${t.installment_number}/${t.total_installments})`;
                }
                if (description.length > 35) {
                    description = description.substring(0, 35) + '...';
                }
                doc.text(description, 45, yPosition + 3);
                
                doc.text(t.is_paid ? 'Pago' : 'Pendente', 130, yPosition + 3);
                doc.text(`R$ ${(t.amount || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 170, yPosition + 3);
                
                yPosition += 7;
            });
        }

        const pdfBytes = doc.output('arraybuffer');

        return new Response(pdfBytes, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': 'attachment; filename=relatorio-financeiro.pdf'
            }
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});